#!/bin/bash
# Claude Stack - Health Check
# Vérifie l'état complet de la stack

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

echo ""
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}   Claude Stack Health Check${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo ""

# 1. Vérifier les secrets
echo -e "${YELLOW}[1/6] Secrets${NC}"
if [ -f "$HOME/.claude/.secrets" ]; then
    PERMS=$(stat -c %a "$HOME/.claude/.secrets" 2>/dev/null)
    if [ "$PERMS" = "600" ]; then
        echo -e "  ${GREEN}✓${NC} .secrets existe (permissions: 600)"
    else
        echo -e "  ${YELLOW}!${NC} .secrets permissions: $PERMS (devrait être 600)"
        ((WARNINGS++))
    fi

    # Vérifier que les variables sont définies
    source "$HOME/.claude/.secrets" 2>/dev/null
    [ -n "$CONTEXT7_API_KEY" ] && echo -e "  ${GREEN}✓${NC} CONTEXT7_API_KEY défini" || { echo -e "  ${RED}✗${NC} CONTEXT7_API_KEY manquant"; ((ERRORS++)); }
    [ -n "$SENTRY_ACCESS_TOKEN" ] && echo -e "  ${GREEN}✓${NC} SENTRY_ACCESS_TOKEN défini" || { echo -e "  ${RED}✗${NC} SENTRY_ACCESS_TOKEN manquant"; ((ERRORS++)); }
    [ -n "$NOTION_TOKEN" ] && echo -e "  ${GREEN}✓${NC} NOTION_TOKEN défini" || { echo -e "  ${RED}✗${NC} NOTION_TOKEN manquant"; ((ERRORS++)); }
else
    echo -e "  ${RED}✗${NC} .secrets introuvable"
    ((ERRORS++))
fi

# 2. Vérifier les CLIs
echo ""
echo -e "${YELLOW}[2/6] CLIs${NC}"
CLIS="claude node npm git gh vercel supabase docker python3"
for cli in $CLIS; do
    if command -v $cli &> /dev/null; then
        VERSION=$($cli --version 2>/dev/null | head -1 | cut -d' ' -f1-3)
        echo -e "  ${GREEN}✓${NC} $cli: $VERSION"
    else
        echo -e "  ${RED}✗${NC} $cli: non trouvé"
        ((ERRORS++))
    fi
done

# 3. Vérifier les MCPs
echo ""
echo -e "${YELLOW}[3/6] MCPs${NC}"
if [ -f "$HOME/.mcp.json" ]; then
    MCP_COUNT=$(cat "$HOME/.mcp.json" | grep -c '"command"' 2>/dev/null || echo 0)
    echo -e "  ${GREEN}✓${NC} .mcp.json existe ($MCP_COUNT MCPs configurés)"

    # Vérifier qu'il n'y a pas de secrets en clair
    SECRETS_IN_MCP=$(grep -cE "ctx7sk|sntryu|ntn_" "$HOME/.mcp.json" 2>/dev/null | head -1 || echo "0")
    if [ "$SECRETS_IN_MCP" -gt 0 ]; then
        echo -e "  ${RED}✗${NC} ATTENTION: $SECRETS_IN_MCP secret(s) en clair dans .mcp.json!"
        ((ERRORS++))
    else
        echo -e "  ${GREEN}✓${NC} Pas de secrets en clair dans .mcp.json"
    fi
else
    echo -e "  ${RED}✗${NC} .mcp.json introuvable"
    ((ERRORS++))
fi

# 4. Vérifier les skills
echo ""
echo -e "${YELLOW}[4/6] Skills${NC}"
SKILL_COUNT=$(find "$HOME/.claude/skills" -maxdepth 1 -type d 2>/dev/null | tail -n +2 | wc -l)
echo -e "  ${GREEN}✓${NC} $SKILL_COUNT skills installés"

# 5. Vérifier les plugins
echo ""
echo -e "${YELLOW}[5/6] Plugins${NC}"
if command -v claude &> /dev/null; then
    PLUGIN_STATUS=$(claude plugin list 2>/dev/null | grep -c "enabled" || echo 0)
    echo -e "  ${GREEN}✓${NC} $PLUGIN_STATUS plugin(s) actif(s)"
else
    echo -e "  ${YELLOW}!${NC} Impossible de vérifier les plugins"
    ((WARNINGS++))
fi

# 6. Vérifier l'espace disque
echo ""
echo -e "${YELLOW}[6/6] Espace disque${NC}"
CLAUDE_SIZE=$(du -sh "$HOME/.claude" 2>/dev/null | cut -f1)
TODOS_COUNT=$(ls "$HOME/.claude/todos" 2>/dev/null | wc -l)
echo -e "  ${GREEN}✓${NC} ~/.claude: $CLAUDE_SIZE"
if [ "$TODOS_COUNT" -gt 100 ]; then
    echo -e "  ${YELLOW}!${NC} $TODOS_COUNT fichiers todos (considérez un nettoyage)"
    ((WARNINGS++))
else
    echo -e "  ${GREEN}✓${NC} $TODOS_COUNT fichiers todos"
fi

# Résumé
echo ""
echo -e "${BLUE}════════════════════════════════════════${NC}"
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}   ✓ Stack en parfait état${NC}"
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}   ! Stack OK avec $WARNINGS warning(s)${NC}"
else
    echo -e "${RED}   ✗ $ERRORS erreur(s), $WARNINGS warning(s)${NC}"
fi
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo ""

exit $ERRORS
