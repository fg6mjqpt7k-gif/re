#!/bin/bash
# Claude Stack - Backup automatique
# Sauvegarde les fichiers de configuration importants

CLAUDE_DIR="$HOME/.claude"
BACKUP_DIR="$CLAUDE_DIR/backups"
DATE=$(date '+%Y%m%d_%H%M%S')
BACKUP_NAME="config_backup_$DATE"
BACKUP_PATH="$BACKUP_DIR/$BACKUP_NAME"

mkdir -p "$BACKUP_PATH"

echo "Backup Claude Stack - $DATE"
echo "================================"

# Fichiers à sauvegarder
FILES_TO_BACKUP=(
    "$HOME/.mcp.json"
    "$CLAUDE_DIR/CLAUDE.md"
    "$CLAUDE_DIR/settings.local.json"
    "$CLAUDE_DIR/.secrets.template"
    "$CLAUDE_DIR/.gitignore"
    "$CLAUDE_DIR/install.sh"
)

# Copier les fichiers
for file in "${FILES_TO_BACKUP[@]}"; do
    if [ -f "$file" ]; then
        cp "$file" "$BACKUP_PATH/"
        echo "  ✓ $(basename $file)"
    fi
done

# Sauvegarder la liste des skills
ls -1 "$CLAUDE_DIR/skills" > "$BACKUP_PATH/skills-list.txt" 2>/dev/null
echo "  ✓ skills-list.txt"

# Sauvegarder la liste des plugins
claude plugin list > "$BACKUP_PATH/plugins-list.txt" 2>/dev/null
echo "  ✓ plugins-list.txt"

# Compresser
cd "$BACKUP_DIR"
tar -czf "$BACKUP_NAME.tar.gz" "$BACKUP_NAME"
rm -rf "$BACKUP_NAME"

echo ""
echo "Backup créé: $BACKUP_DIR/$BACKUP_NAME.tar.gz"

# Garder seulement les 10 derniers backups
cd "$BACKUP_DIR"
ls -t *.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f
echo "Anciens backups nettoyés (garde les 10 derniers)"
