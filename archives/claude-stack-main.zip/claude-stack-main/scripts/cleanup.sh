#!/bin/bash
# Claude Stack - Nettoyage automatique
# Supprime les fichiers temporaires de plus de 7 jours

CLAUDE_DIR="$HOME/.claude"
LOG_FILE="$CLAUDE_DIR/logs/cleanup.log"

mkdir -p "$CLAUDE_DIR/logs"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

log "Début du nettoyage"

# Nettoyer les todos de plus de 7 jours
TODOS_DELETED=$(find "$CLAUDE_DIR/todos" -type f -mtime +7 -delete -print 2>/dev/null | wc -l)
log "Todos supprimés: $TODOS_DELETED"

# Nettoyer les fichiers debug de plus de 14 jours
DEBUG_DELETED=$(find "$CLAUDE_DIR/debug" -type f -mtime +14 -delete -print 2>/dev/null | wc -l)
log "Debug supprimés: $DEBUG_DELETED"

# Nettoyer le cache de plus de 30 jours
CACHE_DELETED=$(find "$CLAUDE_DIR/cache" -type f -mtime +30 -delete -print 2>/dev/null | wc -l)
log "Cache supprimés: $CACHE_DELETED"

# Nettoyer les logs de plus de 30 jours
LOGS_DELETED=$(find "$CLAUDE_DIR/logs" -type f -mtime +30 -delete -print 2>/dev/null | wc -l)
log "Logs supprimés: $LOGS_DELETED"

# Garder seulement les 100 derniers fichiers session-env
cd "$CLAUDE_DIR/session-env" 2>/dev/null && ls -t 2>/dev/null | tail -n +101 | xargs -r rm -rf 2>/dev/null
log "Session-env nettoyé"

log "Nettoyage terminé"

echo "Nettoyage effectué. Voir $LOG_FILE pour les détails."
