#!/bin/bash
# Claude Stack - Mise à jour des skills
# Met à jour tous les skills depuis leurs repos GitHub

CLAUDE_DIR="$HOME/.claude"
SKILL_LOCK="$CLAUDE_DIR/skills/.skill-lock.json"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo "════════════════════════════════════════"
echo "   Mise à jour des Skills"
echo "════════════════════════════════════════"
echo ""

if [ ! -f "$SKILL_LOCK" ]; then
    echo -e "${RED}Erreur: skill-lock.json introuvable${NC}"
    exit 1
fi

# Vérifier que jq est installé
if ! command -v jq &> /dev/null; then
    echo -e "${RED}Erreur: jq requis (apt install jq)${NC}"
    exit 1
fi

# Extraire les skills avec leur source GitHub
SKILLS=$(jq -r '.skills | to_entries[] | "\(.key)|\(.value.source)|\(.value.sourceUrl)"' "$SKILL_LOCK" 2>/dev/null)

UPDATED=0
FAILED=0
SKIPPED=0

while IFS='|' read -r skill_name source source_url; do
    if [ -z "$source_url" ] || [ "$source_url" = "null" ]; then
        echo -e "${YELLOW}⊘${NC} $skill_name: pas de source GitHub"
        ((SKIPPED++))
        continue
    fi

    echo -n "  Checking $skill_name... "

    # Utiliser claude skill update si disponible
    if claude skill update "$skill_name" 2>/dev/null; then
        echo -e "${GREEN}✓${NC}"
        ((UPDATED++))
    else
        echo -e "${YELLOW}skip${NC}"
        ((SKIPPED++))
    fi

done <<< "$SKILLS"

echo ""
echo "════════════════════════════════════════"
echo -e "  Mis à jour: ${GREEN}$UPDATED${NC}"
echo -e "  Ignorés: ${YELLOW}$SKIPPED${NC}"
echo -e "  Échoués: ${RED}$FAILED${NC}"
echo "════════════════════════════════════════"
echo ""
echo "Note: Pour forcer une mise à jour complète:"
echo "  claude skill install <github-user/repo>"
