# Plan de réorganisation complète Claude Code

## Objectif
Tout centraliser sous `~/.claude/` avec une structure claire et fonctionnelle.

---

## Structure actuelle (désorganisée)

```
~/.agents/
├── skills/              ← 33 skills standalone
└── .skill-lock.json     ← Tracking

~/.claude/
├── skills/              ← Symlinks vers .agents (redondant)
└── plugins/marketplaces/claude-plugins-official/
    ├── plugins/*/skills/      ← 14 skills éparpillés
    ├── plugins/*/commands/    ← Commands éparpillées
    ├── plugins/*/agents/      ← Agents éparpillés
    └── plugins/*/hooks/       ← Hooks éparpillés
```

---

## Nouvelle structure (clean)

```
~/.claude/
├── skills/                         ← TOUS les skills (47)
│   ├── standalone/                 ← 33 skills GitHub
│   │   ├── ab-test-setup/
│   │   ├── copywriting/
│   │   ├── ui-ux-pro-max/
│   │   └── ...
│   ├── plugins/                    ← 14 skills de plugins
│   │   ├── stripe-best-practices/
│   │   ├── frontend-design/
│   │   └── ...
│   └── .skill-lock.json            ← Tracking unifié
│
├── commands/                       ← TOUTES les commands
│   ├── commit.md
│   ├── code-review.md
│   ├── feature-dev.md
│   └── ...
│
├── agents/                         ← TOUS les agents
│   ├── code-architect.md
│   ├── code-explorer.md
│   ├── plugin-validator.md
│   └── ...
│
├── hooks/                          ← TOUS les hooks
│   └── (hooks des plugins)
│
├── mcp/                            ← Lien vers config MCP
│   └── .mcp.json → ~/.mcp.json
│
└── plugins/                        ← Plugins (structure originale préservée)
    └── marketplaces/...

~/.agents/                          ← SYMLINKS de compatibilité
├── skills → ~/.claude/skills/standalone
└── .skill-lock.json → ~/.claude/skills/.skill-lock.json
```

---

## Étapes d'exécution

### 1. Backup
```bash
cp -r ~/.agents ~/.agents.backup
cp -r ~/.claude/skills ~/.claude/skills.backup
```

### 2. Créer nouvelle structure
```bash
mkdir -p ~/.claude/skills/standalone
mkdir -p ~/.claude/skills/plugins
mkdir -p ~/.claude/commands
mkdir -p ~/.claude/agents
mkdir -p ~/.claude/hooks
mkdir -p ~/.claude/mcp
```

### 3. Migrer skills standalone
```bash
mv ~/.agents/skills/* ~/.claude/skills/standalone/
mv ~/.agents/.skill-lock.json ~/.claude/skills/
```

### 4. Créer symlinks compatibilité (.agents)
```bash
rm -rf ~/.agents/skills
ln -s ~/.claude/skills/standalone ~/.agents/skills
ln -s ~/.claude/skills/.skill-lock.json ~/.agents/.skill-lock.json
```

### 5. Lier skills des plugins
```bash
# Pour chaque skill de plugin, créer un symlink
ln -s ~/.claude/plugins/.../plugins/stripe/skills/stripe-best-practices \
      ~/.claude/skills/plugins/stripe-best-practices
# etc.
```

### 6. Lier commands des plugins
```bash
# Pour chaque command, créer un symlink
ln -s ~/.claude/plugins/.../plugins/commit-commands/commands/commit.md \
      ~/.claude/commands/commit.md
# etc.
```

### 7. Lier agents des plugins
```bash
# Pour chaque agent, créer un symlink
ln -s ~/.claude/plugins/.../plugins/feature-dev/agents/code-architect.md \
      ~/.claude/agents/code-architect.md
# etc.
```

### 8. Lier config MCP
```bash
ln -s ~/.mcp.json ~/.claude/mcp/.mcp.json
```

### 9. Supprimer anciens symlinks
```bash
# Nettoyer les vieux symlinks dans ~/.claude/skills/ (les 34 symlinks actuels)
```

---

## Fichiers à créer/modifier

| Fichier | Action |
|---------|--------|
| `~/.claude/skills/standalone/*` | Déplacer depuis ~/.agents/skills/ |
| `~/.claude/skills/.skill-lock.json` | Déplacer depuis ~/.agents/ |
| `~/.claude/skills/plugins/*` | Symlinks vers plugins |
| `~/.claude/commands/*` | Symlinks vers plugins |
| `~/.claude/agents/*` | Symlinks vers plugins |
| `~/.agents/skills` | Symlink → ~/.claude/skills/standalone |
| `~/.agents/.skill-lock.json` | Symlink → ~/.claude/skills/.skill-lock.json |

---

## Vérification post-migration

1. **Skills standalone fonctionnels:**
   ```bash
   ls ~/.claude/skills/standalone/ | wc -l  # = 33
   ls ~/.agents/skills/ | wc -l             # = 33 (via symlink)
   ```

2. **Skills plugins accessibles:**
   ```bash
   ls ~/.claude/skills/plugins/ | wc -l     # = 14
   ```

3. **Commands centralisées:**
   ```bash
   ls ~/.claude/commands/
   ```

4. **Agents centralisés:**
   ```bash
   ls ~/.claude/agents/
   ```

5. **CLI skills fonctionne:**
   ```bash
   # Le CLI skills doit toujours pouvoir lire ~/.agents/.skill-lock.json
   ```

---

## Résultat attendu

| Avant | Après |
|-------|-------|
| Skills dans 2 endroits | Skills dans `~/.claude/skills/` |
| Commands éparpillées | Commands dans `~/.claude/commands/` |
| Agents éparpillés | Agents dans `~/.claude/agents/` |
| Hooks éparpillés | Hooks dans `~/.claude/hooks/` |
| MCP dans ~ | MCP lié dans `~/.claude/mcp/` |
| CLI skills → ~/.agents | CLI skills → symlink (compatible) |
