#!/bin/bash
# Claude Stack - Installation Script
# ==================================

set -e

CLAUDE_DIR="$HOME/.claude"
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "========================================"
echo "   Claude Stack Installation"
echo "========================================"
echo ""

# 1. Vérifier les prérequis
echo -e "${YELLOW}[1/5]${NC} Vérification des prérequis..."

check_command() {
    if command -v $1 &> /dev/null; then
        echo -e "  ✓ $1"
        return 0
    else
        echo -e "  ${RED}✗ $1 manquant${NC}"
        return 1
    fi
}

MISSING=0
check_command node || MISSING=1
check_command npm || MISSING=1
check_command git || MISSING=1
check_command claude || MISSING=1

if [ $MISSING -eq 1 ]; then
    echo -e "${RED}Installez les dépendances manquantes et réessayez.${NC}"
    exit 1
fi

# 2. Configurer les secrets
echo ""
echo -e "${YELLOW}[2/5]${NC} Configuration des secrets..."

if [ -f "$CLAUDE_DIR/.secrets" ]; then
    echo -e "  ${GREEN}✓${NC} Fichier .secrets existant"
else
    if [ -f "$CLAUDE_DIR/.secrets.template" ]; then
        cp "$CLAUDE_DIR/.secrets.template" "$CLAUDE_DIR/.secrets"
        chmod 600 "$CLAUDE_DIR/.secrets"
        echo -e "  ${YELLOW}!${NC} Fichier .secrets créé depuis le template"
        echo -e "  ${YELLOW}!${NC} Éditez ~/.claude/.secrets avec vos tokens"
        NEED_SECRETS=1
    else
        echo -e "  ${RED}✗${NC} Template .secrets.template introuvable"
    fi
fi

# 3. Configurer bashrc
echo ""
echo -e "${YELLOW}[3/5]${NC} Configuration du shell..."

if grep -q "source.*\.claude/\.secrets" ~/.bashrc 2>/dev/null; then
    echo -e "  ${GREEN}✓${NC} Secrets déjà dans .bashrc"
else
    echo '# Claude Stack secrets
[ -f ~/.claude/.secrets ] && source ~/.claude/.secrets' >> ~/.bashrc
    echo -e "  ${GREEN}✓${NC} Ajouté à .bashrc"
fi

# 4. Copier .mcp.json
echo ""
echo -e "${YELLOW}[4/5]${NC} Configuration MCP..."

if [ -f "$CLAUDE_DIR/.mcp.json.template" ]; then
    if [ ! -f "$HOME/.mcp.json" ]; then
        cp "$CLAUDE_DIR/.mcp.json.template" "$HOME/.mcp.json"
        echo -e "  ${GREEN}✓${NC} .mcp.json installé"
    else
        echo -e "  ${YELLOW}!${NC} .mcp.json existe déjà (non écrasé)"
    fi
else
    echo -e "  ${YELLOW}!${NC} Pas de template MCP trouvé"
fi

# 5. Résumé
echo ""
echo -e "${YELLOW}[5/5]${NC} Installation terminée!"
echo ""
echo "========================================"
echo "   Prochaines étapes"
echo "========================================"

if [ "$NEED_SECRETS" = "1" ]; then
    echo ""
    echo -e "${YELLOW}1. Configurez vos tokens:${NC}"
    echo "   nano ~/.claude/.secrets"
    echo ""
fi

echo -e "${YELLOW}2. Rechargez votre shell:${NC}"
echo "   source ~/.bashrc"
echo ""
echo -e "${YELLOW}3. Vérifiez les MCPs:${NC}"
echo "   claude mcp list"
echo ""
echo -e "${GREEN}Stack Claude prête!${NC}"
