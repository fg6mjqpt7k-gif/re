#!/bin/bash
# Status line personnalisée pour Claude Code
# Modes: normal, auto (bypass), L451 (white label)

input=$(cat)

# Extraction des données
MODEL=$(echo "$input" | jq -r '.model.display_name // "Claude"')
DIR=$(echo "$input" | jq -r '.workspace.current_dir // "."' | xargs basename)
COST=$(echo "$input" | jq -r '.cost.total_cost_usd // 0')
USED=$(echo "$input" | jq -r '.context_window.used_percentage // 0' | cut -d'.' -f1)
ADDED=$(echo "$input" | jq -r '.cost.total_lines_added // 0')
REMOVED=$(echo "$input" | jq -r '.cost.total_lines_removed // 0')
CWD=$(echo "$input" | jq -r '.workspace.current_dir // "."')

# Branche git (silencieux si pas un repo)
BRANCH=$(git -C "$CWD" branch --show-current 2>/dev/null)

# Indicateur contexte avec couleur
if [ "$USED" -lt 50 ]; then
    CTX="🟢 ${USED}%"
elif [ "$USED" -lt 80 ]; then
    CTX="🟡 ${USED}%"
else
    CTX="🔴 ${USED}%"
fi

# Formater le coût
COST_FMT=$(printf "%.2f" "$COST")

# === MODE L451 (White Label - aucune info technique) ===
if [ "$CLAUDE_MODE" = "L451" ]; then
    # Affichage minimal, pas de coût, pas de contexte, pas de bypass
    echo "◉ Assistant │ 📁 $DIR${BRANCH:+ │ 🌿 $BRANCH}"
    exit 0
fi

# === MODE AUTO (Bypass permissions) ===
if [ "$CLAUDE_MODE" = "auto" ]; then
    OUTPUT="⚡ AUTO [$MODEL] │ 📁 $DIR"
    [ -n "$BRANCH" ] && OUTPUT="$OUTPUT │ 🌿 $BRANCH"
    OUTPUT="$OUTPUT │ 💰 \$${COST_FMT} │ $CTX │ +${ADDED} -${REMOVED}"
    echo "$OUTPUT"
    exit 0
fi

# === MODE NORMAL ===
OUTPUT="[$MODEL] 📁 $DIR"
[ -n "$BRANCH" ] && OUTPUT="$OUTPUT ⎸ 🌿 $BRANCH"
OUTPUT="$OUTPUT ⎸ 💰 \$${COST_FMT} ⎸ $CTX ⎸ +${ADDED} -${REMOVED}"

echo "$OUTPUT"
