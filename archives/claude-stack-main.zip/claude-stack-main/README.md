# Claude Stack

> Configuration optimisée pour Claude Code avec skills, MCPs, plugins et automatisations.

**Version**: 2.7.1 | **Skills**: 47 | **MCPs**: 8 | **CLIs**: 13 | **Plugins**: 4

## Installation rapide

```bash
# 1. Cloner le repo
git clone <your-repo-url> ~/.claude

# 2. Lancer l'installation
cd ~/.claude
./install.sh

# 3. Configurer vos tokens
nano ~/.claude/.secrets
# Remplir avec vos propres tokens (voir .secrets.template)

# 4. Recharger le shell
source ~/.bashrc

# 5. Vérifier l'installation
~/.claude/scripts/health-check.sh
```

## Structure

```
~/.claude/
├── CLAUDE.md              # Documentation complète
├── README.md              # Ce fichier
├── install.sh             # Script d'installation
│
├── .secrets.template      # Template pour les tokens
├── .secrets               # Vos tokens (non versionné)
├── .gitignore             # Protection des secrets
├── .mcp.json.template     # Config MCP template
│
├── scripts/
│   ├── health-check.sh    # Vérification de la stack
│   ├── cleanup.sh         # Nettoyage des fichiers temp
│   ├── backup.sh          # Backup de la config
│   └── update-skills.sh   # Mise à jour des skills
│
├── skills/                # 47 skills installés
├── plugins/               # Marketplace de plugins
├── CLI/                   # Symlinks vers les CLIs
└── backups/               # Backups automatiques
```

## Composants

### MCPs (8)

| MCP | Usage |
|-----|-------|
| filesystem | Accès fichiers hors projet |
| memory | Persistance entre sessions |
| sequential-thinking | Raisonnement complexe |
| playwright | Tests E2E |
| chrome-devtools | Debug navigateur |
| context7 | Documentation librairies |
| sentry | Erreurs production |
| notion | Documentation Notion |

### Plugins (4)

| Plugin | Usage |
|--------|-------|
| ralph-loop | Boucles autonomes (TDD, migration) |
| commit-commands | Commits automatisés |
| feature-dev | Workflow feature complet |
| hookify | Création de hooks |

### Skills (47)

Répartis en 9 catégories :
- **Core/Orchestration** (6): auto-orchestrator, brainstorming, git-workflow...
- **Development** (5): test-driven-development, systematic-debugging...
- **Tech Stack** (8): vercel-react-best-practices, stripe-best-practices...
- **Design/Frontend** (4): ui-ux-pro-max, web-artifacts-builder...
- **Marketing** (7): copywriting, content-strategy, email-sequence...
- **Growth/CRO** (4): conversion-optimization, seo-complete...
- **Business Ops** (4): competitive-intel, market-research...
- **Documents** (4): pdf, docx, xlsx, pptx
- **Meta/Utility** (5): mcp-builder, doc-coauthoring...

Voir `CLAUDE.md` pour la liste complète.

### CLIs (13)

```
vercel, gh, supabase, node, npm, npx,
git, docker, python3, pip3, curl, wget, claude
```

## Configuration des tokens

Copiez `.secrets.template` vers `.secrets` et remplissez :

```bash
# Context7 - https://context7.com
export CONTEXT7_API_KEY="your-key"

# Sentry - https://sentry.io/settings/account/api/auth-tokens/
export SENTRY_ACCESS_TOKEN="your-token"

# Notion - https://www.notion.so/my-integrations
export NOTION_TOKEN="your-token"
```

## Scripts utilitaires

```bash
# Vérifier la santé de la stack
~/.claude/scripts/health-check.sh

# Nettoyer les fichiers temporaires
~/.claude/scripts/cleanup.sh

# Créer un backup manuel
~/.claude/scripts/backup.sh

# Mettre à jour les skills
~/.claude/scripts/update-skills.sh
```

## Automatisations

| Tâche | Fréquence | Script |
|-------|-----------|--------|
| Nettoyage | Dimanche 3h | cleanup.sh |
| Backup | Quotidien 2h | backup.sh |

## Tech Stack supportée

| Domaine | Technologies |
|---------|--------------|
| Frontend | Next.js 14+, TypeScript, Tailwind, shadcn/ui |
| Backend | Node.js, Python, Supabase PostgreSQL |
| Auth | Better Auth |
| Payments | Stripe |
| Deploy | Vercel |
| Tests | Playwright, Jest, pytest |

## Commandes utiles

```bash
# Vérifier les MCPs
claude mcp list

# Lister les plugins
claude plugin list

# Lancer une boucle autonome
/ralph-loop "prompt" --max-iterations 20 --completion-promise "DONE"

# Commit automatisé
/commit

# Workflow feature
/feature-dev
```

## Mise à jour

```bash
cd ~/.claude
git pull
./install.sh
```

## Licence

MIT

---

Créé avec Claude Code
