# CLAUDE.md

> **Version**: 2.10.0 | **Updated**: 2026-02-05 | **Skills**: 48 | **MCPs**: 8 | **CLIs**: 14 | **Plugins**: 4

## Table of Contents

- [Principles](#principles)
- [Expert Mode & Prompt Engineering](#expert-mode--prompt-engineering)
- [Tech Stack](#tech-stack)
- [Quick Reference](#quick-reference)
- [Decision Matrix](#decision-matrix)
  - [MCPs](#when-to-use-an-mcp)
  - [Skills](#when-to-use-a-skill)
- [Workflow](#automatic-workflow)
- [Rules](#strict-rules)
- [Skills by Category](#skills-by-category)
- [Troubleshooting](#troubleshooting)
- [Reference Paths](#reference-paths)
- [Plugins](#plugins)
- [CSO - Session Orchestrator](#cso---session-orchestrator)
- [Version History](#version-history)

---

## Principles

- **Maximum autonomy** - Confirmation only for critical decisions
- **One task = complete solution** - Production-ready output
- **No destructive operations** without explicit confirmation
- **Multi-agent automatic** for complex tasks (3+ files)
- **Prompt engineering** - Reformulate natural language requests into structured, optimized prompts before execution
- **Expert mode adaptatif** - Adopt the mindset of a domain expert for each task (DevOps, Security, Marketing, UX, etc.) and switch roles fluidly to deliver professional-grade results
- **CSO autonomy** - At the start of each conversation, check for active CSO sessions and provide a natural status update if any are running

---

## Expert Mode & Prompt Engineering

### Prompt Reformulation

When the user writes in natural language, **always reformulate** the request into a structured prompt before execution:

| User says | Claude reformulates |
|-----------|---------------------|
| "fais moi une landing page" | "Create a conversion-optimized landing page with hero section, value props, social proof, and CTA. Stack: Next.js 14, Tailwind, shadcn/ui. Mobile-first." |
| "y'a un bug dans le login" | "Debug authentication flow: identify root cause, trace error, implement fix with regression test, verify in isolation." |
| "ajoute stripe" | "Integrate Stripe payments: configure SDK, implement checkout session, handle webhooks, add error handling, test with CLI." |

**Process:**
1. Parse intent from natural language
2. Identify implicit requirements
3. Structure as actionable prompt
4. Add relevant constraints (stack, best practices)
5. Execute with full context

### Adaptive Expert Mode

For each task, **adopt the persona of a domain expert** — no limitations. The expertise adapts to ANY field:

**How it works:**
1. **Detect domain** from context (code, question, industry, terminology)
2. **Become the expert** — think, reason, and respond as a senior professional in that field
3. **Apply deep knowledge** — industry standards, best practices, common pitfalls, professional terminology
4. **Challenge like an expert** — question assumptions, spot issues, suggest improvements
5. **Switch fluidly** — change persona mid-conversation if the domain shifts

**Examples (non-exhaustive):**

| Context detected | Expert persona adopted |
|------------------|----------------------|
| React component | Senior Frontend Engineer (perf, a11y, patterns) |
| SQL query | Database Architect (optimization, indexing, normalization) |
| Landing page copy | Conversion Copywriter (hooks, benefits, CTAs) |
| Auth implementation | Security Engineer (OWASP, threat modeling, encryption) |
| Kubernetes config | SRE / Platform Engineer (reliability, scaling, observability) |
| Legal compliance | Legal Counsel (GDPR, contracts, liability) |
| Financial model | CFO / Financial Analyst (metrics, projections, risk) |
| ML pipeline | ML Engineer (features, training, evaluation, MLOps) |
| Music production | Sound Engineer / Producer (mixing, mastering, arrangement) |
| Medical data | Healthcare IT Specialist (HIPAA, HL7, clinical workflows) |
| Game mechanics | Game Designer (balance, progression, engagement) |
| ... | *Any domain — no limits* |

**Mindset:** "What would a 15-year veteran of this field do? What would they check? What would concern them? What's the professional-grade solution?"

---

## Tech Stack

| Domain   | Technologies                                              |
| -------- | --------------------------------------------------------- |
| Frontend | Next.js 14+ (App Router), TypeScript, Tailwind, shadcn/ui |
| Backend  | Node.js, Python, Supabase PostgreSQL                      |
| Auth     | Better Auth                                               |
| Payments | Stripe                                                    |
| Deploy   | Vercel                                                    |
| Tests    | Playwright, Jest, pytest                                  |

---

## Quick Reference

```bash
# Git
git checkout -b feat/xxx       # New feature
git checkout -b fix/xxx        # Bugfix

# Development
npm run dev                    # Start dev server
npm run build                  # Build production
npm test                       # Run tests
npx playwright test            # E2E tests

# Quality
npx tsc --noEmit              # Type check
npm run lint                   # Lint
npm audit                      # Security audit

# Deploy
vercel                         # Preview deploy
vercel --prod                  # Production deploy

# Debug
claude mcp list               # Check MCP servers status
claude plugin list            # Check installed plugins

# Autonomous Loop (Ralph)
/ralph-loop "prompt" --max-iterations 20 --completion-promise "DONE"
/cancel-ralph                 # Stop the loop

# CSO - Session Orchestrator
/cso                          # List active sessions + locks
/cso smart "Name" --desc "..." --files x.py  # Smart launch with locks
/cso stop <id>                # Stop session + release locks
/cso web                      # Open dashboard (port 8420)

# CSO Daemon (systemd user service)
systemctl --user status cso      # Check daemon status
systemctl --user start cso       # Start daemon
systemctl --user stop cso        # Stop daemon
systemctl --user restart cso     # Restart daemon
journalctl --user -u cso -f      # View daemon logs
```

---

## Decision Matrix

### When to Use an MCP vs CLI

| Need                             | Tool                          | Example                |
| -------------------------------- | ----------------------------- | ---------------------- |
| Read/write files outside project | `mcp__filesystem__*`          | System config          |
| Persist data between sessions    | `mcp__memory__*`              | Store user preferences |
| Complex multi-step reasoning     | `mcp__sequential-thinking__*` | Architecture analysis  |
| E2E browser tests                | `mcp__playwright__*`          | Test form              |
| Live browser debug               | `mcp__chrome-devtools__*`     | Inspect network        |
| Notion API                       | `mcp__notion__*`              | Create doc page        |
| Up-to-date library docs          | `mcp__context7__*`            | Search Next.js API     |
| Sentry errors                    | `mcp__sentry__*`              | Analyze prod errors    |
| **GitHub** (issues, PRs)         | **CLI `gh`**                  | `gh pr create`         |
| **Supabase** (DB, migrations)    | **CLI `supabase`**            | `supabase db push`     |
| **Vercel** (deployments)         | **CLI `vercel`**              | `vercel --prod`        |

### When to Use a Skill

#### Core & Orchestration

| Situation                     | Skill                            | Trigger                        |
| ----------------------------- | -------------------------------- | ------------------------------ |
| Iterative + measurable goal   | `ralph-loop` *(plugin)*          | **AUTO** (TDD, migration, fix) |
| Complex task 3+ steps         | `auto-orchestrator`              | **AUTO**                       |
| Before coding a feature       | `brainstorming`                  | **AUTO** or `/`                |
| Complete Git workflow         | `git-workflow`                   | **AUTO** multi-agent           |
| Code review (request/receive) | `code-review`                    | `/code-review`                 |
| Verify before commit          | `verification-before-completion` | **AUTO**                       |
| Security audit                | `security-review`                | **AUTO** end of task           |

#### Development

| Situation                  | Skill                     | Trigger           |
| -------------------------- | ------------------------- | ----------------- |
| Implement with tests first | `test-driven-development` | **AUTO** or `/`   |
| Debug bugs/failures        | `systematic-debugging`    | **AUTO** on error |
| E2E browser tests          | `webapp-testing`          | `/webapp-testing` |
| Automate browser tasks     | `agent-browser`           | Browser context   |
| Create/edit skills         | `writing-skills`          | Skill context     |

#### Tech Stack

| Situation              | Skill                              | Trigger         |
| ---------------------- | ---------------------------------- | --------------- |
| Optimize React/Next    | `vercel-react-best-practices`      | React context   |
| React Native/Expo      | `vercel-react-native-skills`       | Mobile context  |
| Integrate auth         | `better-auth-best-practices`       | Auth context    |
| Integrate Stripe       | `stripe-best-practices`            | Payment context |
| Upgrade Stripe version | `upgrade-stripe`                   | Stripe upgrade  |
| Optimize Postgres      | `supabase-postgres-best-practices` | DB context      |
| Containerize app       | `docker-expert`                    | Docker context  |
| Setup CI/CD            | `github-actions-templates`         | CI/CD context   |

#### Design & Frontend

| Situation                | Skill                   | Trigger          |
| ------------------------ | ----------------------- | ---------------- |
| Design UI/landing page   | `ui-ux-pro-max`         | UI/UX context    |
| Complex claude artifacts | `web-artifacts-builder` | Artifact context |
| Style docs/slides        | `theme-factory`         | Theme context    |
| Generative art           | `algorithmic-art`       | Art context      |

#### Marketing & Content

| Situation              | Skill                       | Trigger            |
| ---------------------- | --------------------------- | ------------------ |
| Set product context    | `product-marketing-context` | `/context`         |
| Write marketing copy   | `copywriting`               | Copy context       |
| Plan content strategy  | `content-strategy`          | Content context    |
| Create email sequences | `email-sequence`            | Email context      |
| Competitor vs pages    | `competitor-alternatives`   | Competitor context |
| Plan product launch    | `launch-strategy`           | Launch context     |
| Define pricing/tiers   | `pricing-strategy`          | Pricing context    |

#### Growth & CRO

| Situation            | Skill                     | Trigger             |
| -------------------- | ------------------------- | ------------------- |
| Optimize conversions | `conversion-optimization` | CRO context         |
| SEO audit + schema   | `seo-complete`            | SEO context         |
| SEO pages at scale   | `programmatic-seo`        | Programmatic SEO    |
| Analytics/A-B tests  | `growth-analytics`        | Measurement context |

#### Business Operations

| Situation               | Skill              | Trigger              |
| ----------------------- | ------------------ | -------------------- |
| Competitor analysis     | `competitive-intel` | Competitor context   |
| Validate business idea  | `market-research`   | Validation context   |
| Setup customer support  | `customer-support`  | Support context      |
| Track KPIs/metrics      | `business-metrics`  | Metrics context      |

#### Documents

| Situation               | Skill  | Trigger            |
| ----------------------- | ------ | ------------------ |
| PDF manipulation        | `pdf`  | PDF context        |
| Word docs + redlining   | `docx` | DOCX context       |
| Spreadsheets + formulas | `xlsx` | Excel context      |
| Presentations           | `pptx` | PowerPoint context |

#### Meta & Utility

| Situation               | Skill                     | Trigger           |
| ----------------------- | ------------------------- | ----------------- |
| Understand skill system | `using-superpowers`       | Meta questions    |
| Create MCP servers      | `mcp-builder`             | MCP context       |
| Co-write documents      | `doc-coauthoring`         | Doc collaboration |
| Internal communications | `internal-comms`          | Internal comms    |
| React video (Remotion)  | `remotion-best-practices` | Video context     |

### When to Use Ralph Loop `AUTO`

**Déclenchement automatique** quand ces critères sont réunis :

| Situation                  | Critères                                   | Iterations | Promise          |
| -------------------------- | ------------------------------------------ | ---------- | ---------------- |
| **TDD Cycle**              | Implement feature + tests until all pass   | 20-30      | `ALL_TESTS_PASS` |
| **Migration/Refactor**     | Convert all X to Y (measurable completion) | 30-50      | `MIGRATION_DONE` |
| **Bug Fix + Verification** | Fix bug + add regression test + verify     | 15-20      | `BUG_FIXED`      |
| **Greenfield Feature**     | New feature from scratch with clear spec   | 25-40      | `FEATURE_DONE`   |
| **Code Quality Loop**      | Fix all lint/type errors iteratively       | 10-15      | `QUALITY_PASS`   |
| **Test Coverage**          | Add tests until coverage target reached    | 20-30      | `COVERAGE_MET`   |

**Critères de déclenchement AUTO :**

- ✅ Tâche avec **critère de complétion mesurable** (tests pass, 0 errors, all files migrated)
- ✅ Tâche **itérative** (red-green-refactor, fix-verify-repeat)
- ✅ **Pas d'input humain** requis pendant l'exécution
- ✅ Dans un **repo git** (rollback possible)

**NE PAS utiliser si :**

- ❌ Décisions de design/architecture requises
- ❌ Opérations destructives (delete, drop)
- ❌ Tâche exploratoire sans critère clair
- ❌ Confirmation humaine nécessaire

**Templates de prompts :**

```bash
# TDD
/ralph-loop "Implement [feature] using TDD. Write failing test, implement, refactor. Output <promise>ALL_TESTS_PASS</promise> when all tests green." --max-iterations 25 --completion-promise "ALL_TESTS_PASS"

# Migration
/ralph-loop "Migrate all class components to functional hooks. Output <promise>MIGRATION_DONE</promise> when no class components remain in src/." --max-iterations 40 --completion-promise "MIGRATION_DONE"

# Bug fix
/ralph-loop "Fix [bug description]. Add regression test. Verify fix. Output <promise>BUG_FIXED</promise> when test passes." --max-iterations 15 --completion-promise "BUG_FIXED"

# Quality
/ralph-loop "Fix all TypeScript errors and ESLint warnings. Output <promise>QUALITY_PASS</promise> when tsc --noEmit and eslint return 0 errors." --max-iterations 15 --completion-promise "QUALITY_PASS"
```

---

## Automatic Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│              CSO AUTO-CHECK (conversation start)                │
│  Check active sessions: /cso (if sessions exist, report status) │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      USER REQUEST                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │  Iterative + Measurable       │
              │  completion criteria?         │
              │  (TDD, migration, quality)    │
              └───────────────────────────────┘
                     │              │
                    YES            NO
                     │              │
                     ▼              │
              ┌───────────────┐     │
              │  ralph-loop   │     │
              │  (autonomous) │     │
              └───────────────┘     │
                     │              │
                     ▼              ▼
              ┌───────────────────────────────┐
              │  Simple task (1-2 files)?     │
              └───────────────────────────────┘
                     │              │
                    YES            NO
                     │              │
                     ▼              ▼
              ┌───────────┐  ┌─────────────────────┐
              │  Direct   │  │  auto-orchestrator  │
              │  (fast)   │  │  (TaskList auto)    │
              └───────────┘  └─────────────────────┘
                     │              │
                     │              ▼
                     │       ┌─────────────────────┐
                     │       │  Shared files?      │
                     │       └─────────────────────┘
                     │              │         │
                     │             YES       NO
                     │              │         │
                     │              ▼         ▼
                     │       ┌──────────┐ ┌──────────────┐
                     │       │git-workflow│ │Direct agents │
                     │       └──────────┘ └──────────────┘
                     │              │         │
                     └──────────────┴─────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │  verification-before-completion│
              │  security-review (if sensitive)│
              └───────────────────────────────┘
```

---

## Strict Rules

| Rule            | Description                                                 |
| --------------- | ----------------------------------------------------------- |
| **Secrets**     | Never in code → environment variables                       |
| **Git**         | Never force push on main/master                             |
| **Deletion**    | Always verify before destructive ops                        |
| **Commits**     | `<type>: <description>` (feat/fix/docs/refactor/test/chore) |
| **Multi-agent** | Use git-workflow for shared files                           |
| **Features**    | Always on branch, never main                                |

---

## Skills by Category (48 installés)

### Core - Orchestration (6) `AUTO`

| Skill                            | Usage                                          |
| -------------------------------- | ---------------------------------------------- |
| `auto-orchestrator`              | 3+ step tasks, multi-agent, 2-step review      |
| `brainstorming`                  | Explore → Design → Plan → Execute (full cycle) |
| `git-workflow`                   | Worktrees, branches, merge/PR                  |
| `code-review`                    | Request/receive reviews                        |
| `verification-before-completion` | Final check before commit                      |
| `security-review`                | Security audit end of task                     |

*Note: `ralph-loop` est un **plugin**, pas un skill (voir section Plugins)*

### Development (5)

| Skill                     | Usage                              |
| ------------------------- | ---------------------------------- |
| `test-driven-development` | Rigorous TDD                       |
| `systematic-debugging`    | Root-cause methodical debug        |
| `webapp-testing`          | E2E Playwright tests               |
| `agent-browser`           | Browser automation CLI             |
| `writing-skills`          | Create, test, package skills (TDD) |

### Tech Stack (8)

| Skill                              | Usage                                     |
| ---------------------------------- | ----------------------------------------- |
| `vercel-react-best-practices`      | 65+ React/Next.js rules + composition     |
| `vercel-react-native-skills`       | React Native/Expo                         |
| `better-auth-best-practices`       | Complete auth (config, plugins, security) |
| `stripe-best-practices`            | Stripe integration                        |
| `upgrade-stripe`                   | Stripe version migration                  |
| `supabase-postgres-best-practices` | 30 Postgres/RLS rules                     |
| `docker-expert`                    | Containerization                          |
| `github-actions-templates`         | CI/CD workflows                           |

### Design/Frontend (4)

| Skill                   | Usage                                        |
| ----------------------- | -------------------------------------------- |
| `ui-ux-pro-max`         | Design intelligence + 50 styles, 97 palettes |
| `web-artifacts-builder` | Complex claude.ai artifacts                  |
| `theme-factory`         | Themes for slides/docs                       |
| `algorithmic-art`       | Generative art p5.js                         |

### Marketing (7)

| Skill                       | Usage                                |
| --------------------------- | ------------------------------------ |
| `product-marketing-context` | Foundation (all skills reference it) |
| `copywriting`               | Marketing copy + editing             |
| `content-strategy`          | Content strategy + social media      |
| `email-sequence`            | Email lifecycle sequences            |
| `competitor-alternatives`   | vs/alternatives SEO pages            |
| `launch-strategy`           | Product launches                     |
| `pricing-strategy`          | Pricing, tiers, packaging            |

### Growth/CRO (4)

| Skill                     | Usage                                                        |
| ------------------------- | ------------------------------------------------------------ |
| `conversion-optimization` | Full CRO: pages, popups, paywalls, forms, signup, onboarding |
| `seo-complete`            | SEO audit + schema markup                                    |
| `programmatic-seo`        | SEO pages at scale                                           |
| `growth-analytics`        | Tracking + A/B tests                                         |

### Business Operations (4)

| Skill               | Usage                                            |
| ------------------- | ------------------------------------------------ |
| `competitive-intel` | Competitor analysis, feature matrix, monitoring  |
| `market-research`   | Idea validation, TAM/SAM/SOM, customer discovery |
| `customer-support`  | Support setup, templates, escalation, automation |
| `business-metrics`  | KPIs, dashboards, alerts, reporting cadence      |

### Documents (4)

| Skill  | Usage                    |
| ------ | ------------------------ |
| `pdf`  | PDF manipulation         |
| `docx` | Word docs + redlining    |
| `xlsx` | Spreadsheets + formulas  |
| `pptx` | Presentations            |

### Meta/Utility (6)

| Skill                     | Usage                     |
| ------------------------- | ------------------------- |
| `using-superpowers`       | Meta-skill orchestration  |
| `mcp-builder`             | Create custom MCP servers |
| `doc-coauthoring`         | Structured doc co-writing |
| `internal-comms`          | Internal communications   |
| `remotion-best-practices` | React video (Remotion)    |
| `cso`                     | Parallel sessions (`/cso`) |

---

## Troubleshooting

### MCP Issues

| Problem              | Solution                                         |
| -------------------- | ------------------------------------------------ |
| MCP not responding   | Run `claude mcp list` to check status            |
| Authentication error | Verify token in env vars or MCP config           |
| Timeout              | Increase timeout in MCP command or check network |

### Skill Issues

| Problem              | Solution                                           |
| -------------------- | -------------------------------------------------- |
| Skill not triggering | Check description keywords in SKILL.md frontmatter |
| Wrong skill selected | Use explicit `/skill-name` invocation              |
| Skill conflict       | Check `using-superpowers` for priority rules       |

---

## Reference Paths

```
~/.mcp.json                   # MCP servers config (8 MCPs)

~/.claude/
├── CLAUDE.md                 # This file
├── settings.local.json       # Permissions config
├── skills/                   # 47 skills installés
│   └── <skill>/SKILL.md
├── plugins/                  # Plugins
│   └── marketplaces/
├── CLI/                      # Symlinks to all CLIs (13)
│   ├── vercel, gh, supabase  # Services (remplacent MCPs)
│   ├── node, npm, npx        # JS runtime
│   ├── git, docker           # Dev tools
│   ├── python3, pip3         # Python runtime
│   ├── curl, wget            # HTTP utilities
│   └── claude                # Claude Code
└── plans/                    # Saved plans
```

---

## MCP Status (8 actifs)

| MCP                   | Status | Usage                        |
| --------------------- | ------ | ---------------------------- |
| `filesystem`          | ✅     | Files outside project        |
| `memory`              | ✅     | Persist between sessions     |
| `sequential-thinking` | ✅     | Complex multi-step problems  |
| `playwright`          | ✅     | E2E tests, screenshots       |
| `chrome-devtools`     | ✅     | Live debug, network, console |
| `notion`              | ✅     | Notion documentation         |
| `context7`            | ✅     | Up-to-date library docs      |
| `sentry`              | ✅     | Production errors            |

---

## CLIs (14 dans ~/.claude/CLI/)

| CLI | Version | Usage |
| --- | ------- | ----- |
| `vercel` | 50.10.0 | Deployments (remplace MCP) |
| `gh` | 2.45.0 | GitHub PRs, issues (remplace MCP) |
| `supabase` | 2.75.0 | DB, migrations (remplace MCP) |
| `node` | 24.13.0 | Runtime JS |
| `npm` | 11.6.2 | Package manager JS |
| `npx` | 11.6.2 | Run packages |
| `git` | 2.43.0 | Version control |
| `docker` | 29.2.0 | Containers |
| `python3` | 3.12.3 | Runtime Python |
| `pip3` | 24.0 | Package manager Python |
| `curl` | 8.5.0 | HTTP client |
| `wget` | 1.21.4 | HTTP downloader |
| `claude` | 2.1.31 | Claude Code CLI |
| `cso` | 1.0.0 | Session Orchestrator (parallel sessions) |

---

## Code Conventions

```typescript
// TypeScript - Arrow functions, explicit types
const fn = async (id: string): Promise<User> => {
  return await db.users.find(id);
};

// Components - Named exports, Props type
type ButtonProps = {
  label: string;
  onClick: () => void;
};

export const Button = ({ label, onClick }: ButtonProps) => (
  <button onClick={onClick}>{label}</button>
);
```

```python
# Python - Type hints, docstrings
def process(data: list[dict]) -> str:
    """Process data and return summary."""
    return f"Processed {len(data)} items"

# Async
async def fetch_user(user_id: str) -> User:
    return await db.users.get(user_id)
```

---

## Plugins (4 actifs)

| Plugin | Usage | Commande |
|--------|-------|----------|
| `ralph-loop` | Boucles autonomes (TDD, migration) | `/ralph-loop` |
| `commit-commands` | Commits automatisés | `/commit` |
| `feature-dev` | Workflow feature complet | `/feature-dev` |
| `hookify` | Création de hooks | `/hookify` |

### ralph-loop (Autonomous Iteration)

Plugin pour exécuter Claude Code en **boucle autonome** jusqu'à complétion d'une tâche.

```bash
/ralph-loop "Build REST API with tests. Output <promise>DONE</promise> when complete." --max-iterations 30 --completion-promise "DONE"
/cancel-ralph  # Annuler la boucle
```

### commit-commands (Git Automation)

Automatise les commits Git avec messages conventionnels.

```bash
/commit              # Commit interactif
/commit-push-pr      # Commit + push + créer PR
```

### feature-dev (Feature Workflow)

Workflow complet pour le développement de features.

```bash
/feature-dev "nouvelle feature"
```

### Gestion des plugins

```bash
claude plugin list              # Voir plugins installés
claude plugin install <name>    # Installer un plugin
claude plugin disable <name>    # Désactiver
claude plugin enable <name>     # Réactiver
```

---

## CSO - Session Orchestrator v2

**CSO** (Claude Session Orchestrator) permet de lancer et superviser **plusieurs sessions Claude Code en parallèle** avec coordination intelligente.

### Fonctionnalités v2

| Feature | Description |
|---------|-------------|
| **File Locking** | Empêche 2 sessions de modifier le même fichier |
| **Task Specs** | Prompts ultra-précis avec scope limité |
| **Auto-Analysis** | Décide automatiquement : inline / subagent / CSO |
| **Coordination** | Communication et dépendances entre sessions |

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Session principale (cette conversation)                    │
│  → "Lance X en parallèle" → Auto-analyse → CSO si complexe  │
└─────────────────────────────────────────────────────────────┘
                            │
         ┌──────────────────┼──────────────────┐
         ▼                  ▼                  ▼
  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
  │ Session A   │    │ Session B   │    │ Session C   │
  │ LOCK: api.py│    │ LOCK: ui.tsx│    │ LOCK: test/ │
  └─────────────┘    └─────────────┘    └─────────────┘
         │                  │                  │
         └──────────────────┴──────────────────┘
                    Coordination via DB
```

### Commandes `/cso`

| Commande | Description |
|----------|-------------|
| `/cso` | Liste sessions + fichiers verrouillés |
| `/cso smart "Nom" --desc "..." --files x.py` | Lancement intelligent avec locks |
| `/cso start "Nom" --path ~/projet` | Lancement simple |
| `/cso stop <id>` | Arrête + libère les locks |
| `/cso locks` | Affiche tous les fichiers verrouillés |
| `/cso overview` | Vue d'ensemble orchestrateur |
| `/cso analyze "description"` | Analyse sans lancer |
| `/cso web` | Dashboard http://135.125.100.8:8420 |

### Auto-décision : Quand utiliser CSO ?

| Critère | Inline ⚡ | Subagent 🔍 | CSO 🚀 |
|---------|----------|-------------|--------|
| Fichiers | 1-2 | 3-5 | 5+ |
| Durée | < 2 min | 2-10 min | 10+ min |
| Résultat immédiat | Oui | Oui | Non |
| Complexité | Simple | Medium | Complex |

**Mots-clés CSO** : "en parallèle", "background", "CSO", "pendant ce temps"

### Utilisation naturelle

```
Toi: "Refactorise le module auth, fais ça en parallèle"

Claude:
1. Analyse → Complexe, 3 fichiers → CSO recommandé
2. Vérifie conflits → Aucun lock actif
3. Acquiert locks sur auth.py, login.py, session.py
4. Lance session CSO avec prompt précis
5. Continue la conversation pendant que ça tourne
```

### File Locking (Anti-collision)

```bash
# Session A verrouille api.py
cso smart "Task A" --files "api.py"  ✓

# Session B veut aussi api.py
cso smart "Task B" --files "api.py"
# ❌ File conflicts detected:
# - api.py (locked by session abc123)
```

### Dashboard Web

**URL** : http://135.125.100.8:8420

- Vue temps réel des sessions
- Fichiers verrouillés
- Actions Stop/Restart

### Fichiers

```
~/.claude/cso/
├── src/cso/
│   ├── orchestrator/      # v2: locks, specs, coordination
│   ├── cli/               # Commandes
│   ├── daemon/            # Monitoring
│   └── web/               # Dashboard
├── cso.db                 # Sessions + locks + messages
└── cso.yaml               # Config

~/.claude/skills/cso/      # Skill /cso
~/.claude/CLI/cso          # CLI direct
```

---

## Scripts Utilitaires

Scripts dans `~/.claude/scripts/` pour la maintenance de la stack.

| Script | Usage | Fréquence |
|--------|-------|-----------|
| `health-check.sh` | Vérifie l'état de la stack | Manuel |
| `cleanup.sh` | Nettoie les fichiers temporaires | Cron: Dimanche 3h |
| `backup.sh` | Sauvegarde la configuration | Cron: Quotidien 2h |
| `update-skills.sh` | Met à jour les skills | Manuel |

### Exemples

```bash
# Vérifier la santé de la stack
~/.claude/scripts/health-check.sh

# Nettoyage manuel
~/.claude/scripts/cleanup.sh

# Backup manuel
~/.claude/scripts/backup.sh

# Mise à jour des skills
~/.claude/scripts/update-skills.sh
```

---

## Version History

| Version | Date       | Changes                                                                                                                                                                                                         |
| ------- | ---------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 2.10.0  | 2026-02-05 | **CSO added**: Claude Session Orchestrator for parallel sessions. New `/cso` skill, web dashboard (port 8420), tmux-based session management, auto-recovery daemon. |
| 2.9.1   | 2026-02-05 | **Expert Mode expanded**: Removed domain limitations — now ANY field (legal, medical, music, game design, finance, etc.). Added "15-year veteran" mindset. |
| 2.9.0   | 2026-02-05 | **Expert Mode**: Added prompt engineering (natural language → structured prompts) + adaptive expert personas (auto-switch by domain). Fixed skill count in Reference Paths (71→47). Clarified ralph-loop as plugin. |
| 2.8.1   | 2026-02-05 | **Security audit**: Secured ~/.mcp.json permissions (644→600). Verified all 8 MCPs connected, 4 plugins active, 47 skills installed. Stack health: 91%. |
| 2.8.0   | 2026-02-05 | **Major upgrade**: Added 3 plugins (commit-commands, feature-dev, hookify). Added scripts/ directory (health-check, cleanup, backup, update-skills). Initialized MCP memory. Cron jobs for auto-maintenance. README.md for Git. |
| 2.7.1   | 2026-02-05 | **Audit fix**: Corrected skill count to 47 (actual SKILL.md files), not 72 (skill-lock references). skill-lock.json contains GitHub references, not installed skills. CLIs 11→13 (curl/wget). |
| 2.6.0   | 2026-02-05 | Added 4 Business Operations skills: `competitive-intel`, `market-research`, `customer-support`, `business-metrics` (43→47 skills)                                                                              |
| 2.5.2   | 2026-02-04 | Moved ~/CLI to ~/.claude/CLI for centralized organization                                                                                                                                                       |
| 2.5.1   | 2026-02-04 | Fixed CLI count: 11 dev CLIs + utilitaires système                                                                                                                                                              |
| 2.5.0   | 2026-02-04 | Removed redundant MCPs (github, supabase, vercel) → use CLIs instead. 11→8 MCPs                                                                                                                                 |
| 2.4.0   | 2026-02-04 | Removed all hooks (11), simplified workflow, added ~/CLI directory with symlinks                                                                                                                                |
| 2.3.0   | 2026-02-04 | ralph-loop AUTO triggers: Decision Matrix + Workflow integration, templates TDD/migration/bugfix/quality                                                                                                        |
| 2.2.0   | 2026-02-04 | Added ralph-loop plugin for autonomous iteration loops                                                                                                                                                          |
| 2.1.0   | 2026-02-04 | 5 skill fusions (48→43): planning→brainstorming, skill-creator→writing-skills, frontend-design→ui-ux-pro-max, conversion-flows→conversion-optimization, vercel-composition-patterns→vercel-react-best-practices |
| 2.0.0   | 2026-02-03 | Initial structured version with 48 skills, 11 hooks, 11 MCPs                                                                                                                                                    |
