---
name: security-review
description: A general skill for performing security reviews and auditing codebases for vulnerabilities. ALWAYS run this at the end of each task.
---

# Security Review Guidelines

When running a security review on a codebase, follow these structured steps to identify potential vulnerabilities, leaks, and misconfigurations.

## 1. Reconnaissance & Setup

- **Identify Technologies**: Determine if the project matches known stacks (Node.js, Python/Django, Go, etc.).
- **Check .gitignore**: Ensure sensitive files (like `.env`, `*.pem`, `*.key`) are ignored.
- **Review package.json / requirements.txt**: Note outdated or suspicious dependencies.

## 2. Dependency Auditing

Check for known vulnerabilities in project dependencies.

- **Node.js**: `npm audit` or `npm audit --audit-level=high`
- **Python**: `pip-audit` or `safety check`
- **Go**: `govulncheck ./...`
- **Rust**: `cargo audit`

## 3. Secret Scanning

Scan the codebase for hardcoded secrets using Grep tool:

### API Keys & Tokens

- AWS: `AKIA[0-9A-Z]{16}`
- Stripe: `sk_live_[a-zA-Z0-9]{24,}`, `sk_test_[a-zA-Z0-9]{24,}`
- GitHub: `ghp_[a-zA-Z0-9]{36}`, `gho_[a-zA-Z0-9]{36}`
- OpenAI: `sk-[a-zA-Z0-9]{48,}`
- Anthropic: `sk-ant-[a-zA-Z0-9-]{90,}`
- Supabase: `sbp_[a-zA-Z0-9]{40,}`
- Firebase: `AIza[0-9A-Za-z-_]{35}`
- Twilio: `SK[a-f0-9]{32}`
- SendGrid: `SG\.[a-zA-Z0-9-_]{22}\.[a-zA-Z0-9-_]{43}`

### Credentials

- Private Keys: `BEGIN RSA PRIVATE KEY`, `BEGIN OPENSSH PRIVATE KEY`
- Database URLs: `postgres://`, `mysql://`, `mongodb://`
- Generic: `password\s*[:=]`, `secret\s*[:=]`, `api[_-]?key\s*[:=]`
- JWT tokens: `eyJ[a-zA-Z0-9]{10,}\.eyJ`

## 4. Code Analysis (OWASP Top 10)

### Injection Vulnerabilities

- **SQL Injection**: String concatenation in queries, missing parameterized queries
- **Command Injection**: `child_process.exec()`, `subprocess.call(shell=True)`, `os.system()`
- **XSS**: `dangerouslySetInnerHTML`, unescaped user input in templates

### Dangerous Functions

- **JavaScript/TypeScript**: `eval()`, `Function()`, `setTimeout(string)`, `setInterval(string)`
- **Python**: `eval()`, `exec()`, `pickle.load()`, `yaml.load()` without SafeLoader
- **PHP**: `eval()`, `system()`, `exec()`, `unserialize()`

### Authentication & Authorization

- Missing authentication on sensitive routes
- Hardcoded credentials
- Weak password policies
- Missing CSRF protection
- Insecure session management

### Data Exposure

- Sensitive data in logs
- Verbose error messages in production
- Missing input validation
- Unencrypted sensitive data

## 5. Configuration Review

- **Environment variables**: Check `.env.example` exists, `.env` is gitignored
- **CORS**: Verify allowed origins are restrictive
- **HTTPS**: Ensure production uses HTTPS only
- **Headers**: Check security headers (CSP, X-Frame-Options, etc.)

## 6. Infrastructure Checks

- **Docker**: No secrets in Dockerfile, images from trusted sources
- **CI/CD**: Secrets in environment, not in config files
- **Database**: Connection uses SSL, credentials rotated

## 7. Reporting

Create a summary with severity levels:

| Severity    | Description                     | Example                      |
| ----------- | ------------------------------- | ---------------------------- |
| 🔴 CRITICAL | Immediate exploitation possible | Hardcoded production API key |
| 🟠 HIGH     | Significant risk, fix soon      | SQL injection vulnerability  |
| 🟡 MEDIUM   | Moderate risk                   | Missing rate limiting        |
| 🟢 LOW      | Minor issue                     | Verbose error messages       |
| ℹ️ INFO     | Best practice suggestion        | Add security headers         |

### Report Template

```markdown
## Security Review Summary

**Project**: [name]
**Date**: [date]
**Reviewer**: Claude

### Findings

#### 🔴 Critical

- [Finding 1]

#### 🟠 High

- [Finding 1]

#### 🟡 Medium

- [Finding 1]

#### 🟢 Low

- [Finding 1]

### Recommendations

1. [Recommendation 1]
2. [Recommendation 2]

### Verified Secure

- [x] No hardcoded secrets
- [x] Dependencies up to date
- [x] Input validation in place
```
