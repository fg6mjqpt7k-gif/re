---
name: customer-support
version: 1.0.0
description: "Customer support system setup and response templates. Use when the user mentions 'customer support,' 'support tickets,' 'help desk,' 'customer service,' 'handle complaints,' 'support templates,' 'FAQ,' 'canned responses,' or wants to set up or improve their customer support workflow. Covers support system setup, response templates, escalation rules, and support automation."
---

# Customer Support

You help users set up efficient customer support systems and create response templates that maintain quality while minimizing time spent.

**Announce at start:** "I'm using the customer-support skill to set up your support workflow."

---

## Phase 1: Support Assessment

### Step 1: Understand Current State

Ask these questions:

1. **What's your product/service?** (or reference `product-marketing-context.md`)
2. **Current support volume?** (tickets/day or /week)
3. **Current support channels?** (email, chat, social, etc.)
4. **Who handles support now?** (founder, team, outsourced)
5. **Average response time goal?**
6. **Biggest support pain point?**

### Step 2: Support Maturity Assessment

```markdown
## Support Maturity Level

| Stage | Characteristics | You |
|-------|-----------------|-----|
| **1. Founder handles all** | Direct email, no system | [ ] |
| **2. Basic tooling** | Help desk, some templates | [ ] |
| **3. Documented process** | Playbooks, SLAs, tiers | [ ] |
| **4. Scaled support** | Team, automation, metrics | [ ] |

**Current stage:** [1-4]
**Target stage:** [1-4]
```

---

## Phase 2: Support System Setup

### Recommended Stack by Stage

```markdown
## Recommended Tools

### Stage 1-2 (Solo/Small)
- **Help desk:** Crisp (free tier) or Intercom (startup program)
- **Knowledge base:** Notion public page or GitBook
- **Email:** Help Scout or Front

### Stage 3-4 (Scaling)
- **Help desk:** Intercom, Zendesk, or Freshdesk
- **Knowledge base:** Intercom Articles or Zendesk Guide
- **Automation:** Intercom bots or custom
- **Analytics:** Built-in + Metabase for custom
```

### Essential Setup Checklist

```markdown
## Support Setup Checklist

### Must Have (Day 1)
- [ ] Shared inbox (not personal email)
- [ ] Auto-reply confirming receipt
- [ ] 5-10 canned responses for common issues
- [ ] FAQ page (even if basic)
- [ ] Escalation path defined

### Should Have (Week 1)
- [ ] Help center with top 20 articles
- [ ] Response templates for all common issues
- [ ] Internal notes system
- [ ] Basic categorization/tagging
- [ ] SLA defined (response time targets)

### Nice to Have (Month 1)
- [ ] Chatbot for common questions
- [ ] Customer satisfaction survey (CSAT)
- [ ] Support metrics dashboard
- [ ] Escalation automation
- [ ] Integration with product (user context)
```

---

## Phase 3: Response Templates

### Template Structure

Every response should follow:

```markdown
## Template: [Issue Category]

**Trigger:** [When to use this]
**Tone:** [Empathetic / Neutral / Apologetic]
**Goal:** [Resolve / Deflect to docs / Escalate]

---

**Subject:** [If email]

Hi [Name],

[Acknowledge their issue in their words]

[Solution or next step]

[Set expectation for resolution]

[Offer additional help]

Best,
[Your name]

---

**Internal notes:**
- Common follow-ups: [what they usually ask next]
- Escalate if: [conditions]
- Related docs: [links]
```

### Core Template Library

#### Acknowledgment (First Response)

```markdown
## Template: Acknowledgment

Hi [Name],

Thanks for reaching out — I've got your message about [brief issue summary].

I'm looking into this now and will get back to you within [timeframe].

If you have any additional details that might help, feel free to share them.

Talk soon,
[Name]
```

#### Bug Report Response

```markdown
## Template: Bug Report

Hi [Name],

Thanks for reporting this — I can see how frustrating [specific issue] would be.

I've logged this with our team and we're investigating. Here's what I know so far:
- [What you've confirmed]
- [What you're still checking]

I'll update you as soon as we have more info, but expect to hear back within [timeframe].

In the meantime, [workaround if any].

Thanks for your patience,
[Name]
```

#### Feature Request Response

```markdown
## Template: Feature Request

Hi [Name],

Thanks for suggesting [feature] — I appreciate you taking the time to share this.

I've added your request to our feedback log. While I can't promise a timeline, knowing this matters to you helps us prioritize.

A few quick questions that would help us understand better:
- [Clarifying question about use case]
- [How urgent is this for you?]

Thanks again for helping us improve,
[Name]
```

#### How-To Question

```markdown
## Template: How-To

Hi [Name],

Great question! Here's how to [task]:

1. [Step 1]
2. [Step 2]
3. [Step 3]

I've also linked our guide on this: [Help article URL]

Let me know if you run into any issues following these steps.

Best,
[Name]
```

#### Billing Issue

```markdown
## Template: Billing Issue

Hi [Name],

Thanks for reaching out about your billing concern.

I've looked into your account and here's what I found:
- [What happened]
- [Why it happened]
- [What we're doing about it]

[If refund: "I've processed a refund of $X which should appear in 5-10 business days."]
[If no refund: "Here's what I can offer instead: [alternative]"]

I'm sorry for any inconvenience this caused. Let me know if you have any questions.

Best,
[Name]
```

#### Angry Customer

```markdown
## Template: Angry Customer

Hi [Name],

I completely understand your frustration, and I'm sorry we let you down.

You're right that [acknowledge their specific complaint]. That's not the experience we want for you.

Here's what I'm doing to fix this:
1. [Immediate action]
2. [Follow-up action]
3. [Prevention for future]

I'd like to [make it right offer: refund, credit, call, etc.].

Can we schedule a quick call so I can make sure this is fully resolved? [Or: "Please let me know if there's anything else I can do."]

[Name]
```

#### Churn/Cancellation

```markdown
## Template: Cancellation

Hi [Name],

I've processed your cancellation request — your account will remain active until [date].

Before you go, I'd love to understand what didn't work for you. Would you mind sharing:
- What made you decide to cancel?
- Is there anything we could have done differently?

No pressure to respond, but your feedback genuinely helps us improve.

If anything changes, you're always welcome back. Your data will be saved for [X days].

Thanks for giving us a try,
[Name]
```

#### Escalation to User

```markdown
## Template: Escalation

Hi [Name],

Thanks for your patience on this. I've escalated your case to [senior support / engineering / manager] because [reason].

Here's what happens next:
- [Who will contact them]
- [Expected timeframe]
- [What they're looking into]

You'll hear from [person/team] within [timeframe]. If you don't, please reply to this email and I'll follow up personally.

Best,
[Name]
```

---

## Phase 4: Escalation Rules

```markdown
## Escalation Matrix

### Tier 1 (Front-line)
**Handles:**
- How-to questions
- Basic troubleshooting
- Account/billing questions
- Feature requests (logging)

**Escalate if:**
- Bug confirmed and blocking
- Customer explicitly angry
- Legal/compliance mentioned
- Refund > $[threshold]

### Tier 2 (Senior Support)
**Handles:**
- Complex technical issues
- Angry customers
- Refund decisions
- Bug triage

**Escalate if:**
- Bug affects multiple users
- Potential security issue
- Churn risk (high-value customer)
- Legal threat

### Tier 3 (Engineering/Founder)
**Handles:**
- Critical bugs
- Security incidents
- Legal issues
- VIP customers

**Response time:**
- P1 (site down): 15 min
- P2 (major bug): 2 hours
- P3 (other): 24 hours
```

---

## Phase 5: Automation Setup

### Chatbot Decision Tree

```markdown
## Support Bot Flow

### Entry
"Hi! How can I help you today?"
- [ ] I have a technical issue
- [ ] I have a billing question
- [ ] I want to cancel
- [ ] I need to talk to a human
- [ ] Something else

### Technical Issue Path
"What best describes your issue?"
- [ ] Can't log in → [Password reset article]
- [ ] Feature not working → [Ask for details, create ticket]
- [ ] Error message → [Ask for screenshot, create ticket]
- [ ] How do I... → [Search help center]

### Billing Path
"What do you need help with?"
- [ ] Update payment method → [Link to settings]
- [ ] Download invoice → [Link to billing]
- [ ] Unexpected charge → [Create ticket, priority]
- [ ] Request refund → [Create ticket, priority]

### Cancellation Path
"I'm sorry to hear that. Before you go:"
- [ ] Show save offer (discount, pause, downgrade)
- [ ] If declined → [Process cancellation, trigger exit survey]

### Human Handoff
"I'll connect you with our team. Expected wait: [X min]"
- [ ] Collect name, email, brief issue
- [ ] Create ticket, assign to available agent
```

### Auto-Tagging Rules

```markdown
## Auto-Tag Rules

| If message contains | Apply tag | Priority |
|---------------------|-----------|----------|
| "cancel", "refund" | churn-risk | High |
| "bug", "broken", "error" | bug-report | Medium |
| "how do I", "how to" | how-to | Low |
| "urgent", "ASAP", "!!" | urgent | High |
| "love", "great", "thanks" | positive | Low |
| "lawyer", "legal", "sue" | legal | Critical |
```

---

## Phase 6: Metrics & Monitoring

```markdown
## Support Metrics Dashboard

### Response Metrics
| Metric | Target | Current |
|--------|--------|---------|
| First response time | < 4 hrs | |
| Resolution time | < 24 hrs | |
| First contact resolution | > 70% | |

### Volume Metrics
| Metric | This Week | Trend |
|--------|-----------|-------|
| Total tickets | | |
| Tickets per customer | | |
| By category | | |

### Quality Metrics
| Metric | Target | Current |
|--------|--------|---------|
| CSAT score | > 4.5/5 | |
| NPS (from support) | > 50 | |
| Escalation rate | < 10% | |

### Alerts
- [ ] Response time > 8 hrs → Slack alert
- [ ] CSAT < 3 → Manager review
- [ ] Volume spike > 2x → Investigate
```

---

## Phase 7: Knowledge Base Structure

```markdown
## Help Center Structure

### Getting Started
- Quick start guide
- Account setup
- First [action]

### Features
- [Feature 1] guide
- [Feature 2] guide
- [Feature 3] guide

### Billing & Account
- Pricing plans explained
- How to upgrade/downgrade
- Payment methods
- Invoices and receipts
- Cancel subscription

### Troubleshooting
- Common issues
- Error messages
- Can't log in
- [Product-specific issues]

### FAQ
- Top 10 questions (from actual tickets)

### Contact
- How to reach us
- Response time expectations
```

---

## Tips

- **Speed matters more than perfection** — A fast "I'm looking into it" beats a slow perfect answer
- **Use customer's words** — Mirror their language in your response
- **One issue per reply** — Don't overwhelm; solve one thing at a time
- **Always set expectations** — Tell them when they'll hear back
- **Turn complaints into docs** — Every repeated question = missing documentation
- **Track everything** — You can't improve what you don't measure

---

## Integration

This skill works with:
- `product-marketing-context` — Understand product for accurate support
- `copywriting` — Match brand voice in responses
- `business-metrics` — Track support KPIs
