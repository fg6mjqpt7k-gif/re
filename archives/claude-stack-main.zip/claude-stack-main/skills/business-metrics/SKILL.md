---
name: business-metrics
version: 1.0.0
description: "Business metrics tracking, KPI dashboards, and alert setup. Use when the user mentions 'business metrics,' 'KPIs,' 'dashboard,' 'track revenue,' 'MRR,' 'churn rate,' 'analytics,' 'business health,' 'metrics dashboard,' or wants to monitor their business performance. Covers metric selection, dashboard design, alert thresholds, and reporting cadence."
---

# Business Metrics

You help users define, track, and act on the right business metrics for their stage and model.

**Announce at start:** "I'm using the business-metrics skill to set up your metrics framework."

---

## Phase 1: Business Context

### Step 1: Understand the Business

Ask these questions:

1. **Business model?** (SaaS, marketplace, e-commerce, service, etc.)
2. **Current stage?** (Pre-launch, MVP, Growth, Scale)
3. **Revenue model?** (Subscription, one-time, usage-based, ads)
4. **Current MRR/ARR?** (or revenue run rate)
5. **Team size?** (Solo, small team, scaled)
6. **Primary goal right now?** (Validate, grow users, grow revenue, reduce churn)

---

## Phase 2: Metric Selection

### SaaS Metrics (Subscription)

```markdown
## Core SaaS Metrics

### Revenue
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| MRR | Sum of monthly recurring revenue | Core health indicator |
| ARR | MRR × 12 | Annual planning, valuation |
| Net Revenue Retention | (MRR + expansion - churn) / MRR | Growth without new customers |
| ARPU | MRR / Active customers | Pricing health |

### Growth
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| MRR Growth Rate | (MRR this month - last) / last | Momentum |
| New MRR | MRR from new customers | Acquisition engine |
| Expansion MRR | MRR from upgrades | Product-market fit signal |
| Churned MRR | MRR lost to cancellations | Retention health |

### Customers
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Total Customers | Count of paying accounts | Scale |
| New Customers | New paying accounts this period | Acquisition |
| Churn Rate | Lost customers / Total customers | Retention |
| Logo Retention | 1 - Churn rate | Stickiness |

### Unit Economics
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| CAC | Sales + Marketing / New customers | Acquisition efficiency |
| LTV | ARPU × Avg lifespan (1/churn) | Customer value |
| LTV:CAC | LTV / CAC | Business viability (target >3) |
| Payback Period | CAC / ARPU | Cash efficiency |

### Engagement
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| DAU/MAU | Daily active / Monthly active | Stickiness |
| Feature Adoption | Users using feature / Total users | Product value |
| Time to Value | Days from signup to first value | Onboarding health |
```

### Marketplace Metrics

```markdown
## Core Marketplace Metrics

### Volume
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| GMV | Total transaction value | Scale |
| Take Rate | Revenue / GMV | Monetization |
| Transactions | Count of completed transactions | Activity |
| Average Order Value | GMV / Transactions | Basket size |

### Liquidity
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Fill Rate | Completed / Requested transactions | Market efficiency |
| Time to Transaction | Days from listing to sale | Velocity |
| Supply/Demand Ratio | Sellers / Buyers | Balance |

### Retention
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Buyer Retention | Repeat buyers / Total buyers | Demand stickiness |
| Seller Retention | Active sellers this month / last | Supply health |
| Cohort GMV | GMV by signup cohort over time | True retention |
```

### E-commerce Metrics

```markdown
## Core E-commerce Metrics

### Revenue
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Revenue | Total sales | Scale |
| AOV | Revenue / Orders | Basket size |
| Revenue per Visit | Revenue / Sessions | Traffic efficiency |

### Conversion
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Conversion Rate | Orders / Sessions | Funnel efficiency |
| Cart Abandonment | Abandoned / Started carts | Checkout friction |
| Add to Cart Rate | Add to carts / Sessions | Product appeal |

### Retention
| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Repeat Purchase Rate | Repeat customers / Total | Loyalty |
| Purchase Frequency | Orders / Customers | Engagement |
| Customer Lifetime Value | AOV × Frequency × Lifespan | Long-term value |
```

---

## Phase 3: Stage-Appropriate Focus

### What to Track by Stage

```markdown
## Metrics by Stage

### Pre-Launch / MVP
**Focus:** Validation signals
| Metric | Target | Tool |
|--------|--------|------|
| Waitlist signups | Growing | Email tool |
| Landing page conversion | >5% | Analytics |
| Customer interviews | 20+ | Manual |
| Willingness to pay signals | Qualitative | Interviews |

### Early (0-$10k MRR)
**Focus:** Product-market fit
| Metric | Target | Tool |
|--------|--------|------|
| Activation rate | >40% | Product analytics |
| Weekly active users | Growing | Product analytics |
| Churn rate | <10%/month | Stripe/manual |
| NPS | >40 | Survey tool |
| Qualitative feedback | Weekly | Intercom/calls |

### Growth ($10k-$100k MRR)
**Focus:** Scalable acquisition
| Metric | Target | Tool |
|--------|--------|------|
| MRR growth | >10%/month | Stripe/ChartMogul |
| CAC | Decreasing | Calculated |
| LTV:CAC | >3 | Calculated |
| Payback period | <12 months | Calculated |
| Net Revenue Retention | >100% | Calculated |

### Scale ($100k+ MRR)
**Focus:** Efficiency and expansion
| Metric | Target | Tool |
|--------|--------|------|
| Net Revenue Retention | >120% | Revenue tool |
| Gross margin | >70% | Accounting |
| Rule of 40 | Growth% + Margin% > 40 | Calculated |
| Sales efficiency | >1 | Calculated |
| Expansion MRR % | >30% of new MRR | Revenue tool |
```

---

## Phase 4: Dashboard Design

### Essential Dashboard Layout

```markdown
## Metrics Dashboard Structure

### Top Row: Health Indicators
┌─────────────┬─────────────┬─────────────┬─────────────┐
│     MRR     │   Growth    │   Churn     │  LTV:CAC    │
│   $XX,XXX   │   +XX%      │   X.X%      │    X.X      │
│   ▲ vs last │   ▲ vs last │   ▼ vs last │   ▲ vs last │
└─────────────┴─────────────┴─────────────┴─────────────┘

### Second Row: Trends (Charts)
┌─────────────────────────┬─────────────────────────┐
│   MRR Over Time         │   Customer Growth       │
│   [Line chart 12mo]     │   [Line chart 12mo]     │
└─────────────────────────┴─────────────────────────┘

### Third Row: Breakdown
┌─────────────────────────┬─────────────────────────┐
│   MRR Movement          │   Cohort Retention      │
│   New: $X               │   [Cohort grid]         │
│   Expansion: $X         │                         │
│   Churn: -$X            │                         │
│   Net: $X               │                         │
└─────────────────────────┴─────────────────────────┘

### Bottom Row: Leading Indicators
┌─────────────┬─────────────┬─────────────┬─────────────┐
│   Signups   │  Activation │   Trials    │   Pipeline  │
│   This Week │   Rate      │   Active    │   Value     │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

### Tool Recommendations

```markdown
## Dashboard Tools by Budget

### Free / Low Budget
- **Stripe Dashboard** — Basic revenue metrics
- **Google Sheets** — Custom calculations
- **Notion** — Manual weekly updates
- **Plausible/Umami** — Privacy-friendly analytics

### Growth Budget ($50-200/mo)
- **ChartMogul** — SaaS metrics (from Stripe)
- **Baremetrics** — Revenue analytics
- **Mixpanel/Amplitude** — Product analytics
- **Metabase** — Custom dashboards (self-host)

### Scale Budget ($200+/mo)
- **Looker/Tableau** — Enterprise BI
- **ProfitWell** — Free revenue metrics
- **Heap** — Auto-capture analytics
- **Custom** — Data warehouse + dbt + BI tool
```

---

## Phase 5: Alert Setup

### Critical Alerts

```markdown
## Alert Configuration

### Revenue Alerts (Critical)
| Trigger | Threshold | Channel | Action |
|---------|-----------|---------|--------|
| Daily revenue drop | >50% vs avg | SMS + Slack | Investigate immediately |
| Payment failure spike | >10% of charges | Slack | Check Stripe status |
| Large churn | Single customer >$500 MRR | Email | Founder outreach |
| MRR decline | 2 consecutive days | Slack | Review causes |

### Growth Alerts (Warning)
| Trigger | Threshold | Channel | Action |
|---------|-----------|---------|--------|
| Signup drop | >30% WoW | Slack | Check funnel |
| Trial conversion drop | >20% vs avg | Slack | Review onboarding |
| Activation rate drop | >10% vs avg | Slack | Check product |
| CAC increase | >25% MoM | Email | Review spend |

### Engagement Alerts (Informational)
| Trigger | Threshold | Channel | Action |
|---------|-----------|---------|--------|
| Feature adoption spike | >2x usage | Slack | Double down |
| Support ticket spike | >2x daily avg | Slack | Check for issues |
| NPS drop | <30 or >10pt drop | Email | Customer interviews |
```

### Alert Setup by Tool

```markdown
## How to Set Up Alerts

### Stripe
- Dashboard → Radar → Rules → Custom
- Webhook to Slack for failed payments

### ChartMogul
- Settings → Alerts → Add alert
- MRR change, churn threshold

### Custom (Recommended)
1. Data warehouse (BigQuery/Postgres)
2. Daily job calculates metrics
3. Compare to thresholds
4. Send to Slack/Email via webhook

### Zapier/Make (Quick)
- Stripe trigger → Filter → Slack
- Good for simple alerts, limited logic
```

---

## Phase 6: Reporting Cadence

### Weekly Metrics Review

```markdown
## Weekly Metrics Report

### Template (5 min to complete)

**Week of [date]**

#### Headline Numbers
| Metric | This Week | Last Week | Change |
|--------|-----------|-----------|--------|
| MRR | | | |
| New Customers | | | |
| Churned Customers | | | |
| Net MRR Change | | | |

#### What Went Well
-

#### What Needs Attention
-

#### Key Actions This Week
- [ ]

---

**Send to:** [Yourself / Team / Investors]
**Tool:** [Notion / Email / Slack]
```

### Monthly Business Review

```markdown
## Monthly Business Review

### Financial Summary
| Metric | This Month | Last Month | MoM | Target |
|--------|------------|------------|-----|--------|
| Revenue | | | | |
| MRR | | | | |
| Expenses | | | | |
| Net | | | | |
| Runway | | | | |

### Growth Summary
| Metric | This Month | Target | Status |
|--------|------------|--------|--------|
| New MRR | | | 🟢🟡🔴 |
| Churn Rate | | | 🟢🟡🔴 |
| Net Revenue Retention | | | 🟢🟡🔴 |
| CAC | | | 🟢🟡🔴 |

### Cohort Analysis
[Include cohort retention chart]

### Channel Performance
| Channel | Signups | Customers | CAC | Trend |
|---------|---------|-----------|-----|-------|
| Organic | | | | |
| Paid | | | | |
| Referral | | | | |

### Top Wins
1.
2.

### Top Concerns
1.
2.

### Priorities Next Month
1.
2.
3.
```

---

## Phase 7: Metric Calculations

### Formulas Reference

```markdown
## Calculation Reference

### MRR
- **New MRR:** Sum of first payments from new customers
- **Expansion MRR:** Upgrades + add-ons from existing
- **Contraction MRR:** Downgrades from existing
- **Churned MRR:** MRR from cancelled customers
- **Net New MRR:** New + Expansion - Contraction - Churned

### Churn
- **Logo Churn:** Lost customers / Start of period customers
- **Revenue Churn:** Churned MRR / Start of period MRR
- **Net Revenue Churn:** (Churned - Expansion) / Start MRR
  - Negative = good (expansion > churn)

### LTV & CAC
- **LTV (Simple):** ARPU / Monthly churn rate
- **LTV (Better):** ARPU × Gross margin / Monthly churn rate
- **CAC:** (Sales cost + Marketing cost) / New customers
- **Payback:** CAC / (ARPU × Gross margin)

### Engagement
- **DAU/MAU Ratio:** Daily active users / Monthly active users
  - >25% = high engagement (like social apps)
  - 10-25% = good (most SaaS)
  - <10% = concerning
```

---

## Quick Start: Minimum Viable Metrics

For bootstrapped/solo founders, start here:

```markdown
## Minimum Viable Metrics (Weekly, 10 min)

### Track in Spreadsheet
| Metric | Week 1 | Week 2 | Week 3 | Week 4 |
|--------|--------|--------|--------|--------|
| MRR | | | | |
| New customers | | | | |
| Churned customers | | | | |
| Active users (WAU) | | | | |
| Support tickets | | | | |

### Review Questions
1. Is MRR growing? Why/why not?
2. Are new customers converting? If not, why?
3. Are customers churning? If so, why?
4. Are users engaging? If not, why?

### One Action
Based on above, what's the ONE thing to fix this week?
```

---

## Tips

- **Fewer metrics, more action** — 5 metrics you act on > 50 you ignore
- **Leading over lagging** — Signups today predict revenue tomorrow
- **Cohort everything** — Averages lie, cohorts reveal truth
- **Set targets** — Metrics without targets are just trivia
- **Review weekly** — Metrics you don't review don't matter
- **Automate collection** — Manual tracking doesn't scale

---

## Integration

This skill works with:
- `growth-analytics` — Event tracking implementation
- `customer-support` — Support metrics
- `competitive-intel` — Benchmark against competitors
- `pricing-strategy` — Revenue optimization
