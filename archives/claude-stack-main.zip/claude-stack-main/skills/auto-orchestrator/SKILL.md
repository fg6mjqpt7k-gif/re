---
name: auto-orchestrator
description: Orchestration automatique des taches complexes. S'active automatiquement pour toute tache necessitant 3+ etapes, multi-fichiers, ou developpement feature. Gere le dispatch d'agents, l'isolation worktree, la tasklist, le systeme de review 2 etapes et la verification.
---

# Auto-Orchestrator

## Declenchement automatique

Ce skill s'active AUTOMATIQUEMENT quand :

- Tache avec 3+ etapes distinctes
- Modification de 3+ fichiers
- Creation d'une feature complete
- Developpement d'une page/composant
- Bug complexe touchant plusieurs modules
- Refactoring multi-fichiers
- Debug avec 2+ failures independantes

## Workflow automatique

```
ENTREE: Demande utilisateur
          |
          v
+-------------------------------------------+
|  PHASE 1: ANALYSE (automatique)           |
|  -----------------------------------      |
|  - Identifier les sous-taches             |
|  - Detecter les dependances               |
|  - Evaluer si parallelisable              |
|  - Identifier les fichiers touches        |
|  - Grouper par domaine independant        |
+-------------------------------------------+
          |
          v
+-------------------------------------------+
|  PHASE 2: TASKLIST (automatique)          |
|  -----------------------------------      |
|  - Creer TaskCreate pour chaque tache     |
|  - Definir les dependances (blockedBy)    |
|  - Assigner les scopes fichiers           |
|  - Extraire le texte complet de chaque    |
|    tache pour les subagents               |
+-------------------------------------------+
          |
          v
+-------------------------------------------+
|  PHASE 3: ISOLATION (si necessaire)       |
|  -----------------------------------      |
|  SI fichiers partages entre agents:       |
|  - Creer worktrees automatiquement        |
|  - Un worktree par agent                  |
|  SINON:                                   |
|  - Travailler dans le meme espace         |
+-------------------------------------------+
          |
          v
+-------------------------------------------+
|  PHASE 4: EXECUTION                       |
|  -----------------------------------      |
|  Pour chaque tache:                       |
|  1. Dispatcher subagent implementeur      |
|  2. Repondre aux questions si besoin      |
|  3. Subagent implemente + commit          |
|  4. Review spec compliance (obligatoire)  |
|  5. Review code quality (obligatoire)     |
|  6. Marquer tache complete                |
+-------------------------------------------+
          |
          v
+-------------------------------------------+
|  PHASE 5: VERIFICATION (obligatoire)      |
|  -----------------------------------      |
|  - TypeScript check (si .ts/.tsx)         |
|  - Tests unitaires (si existent)          |
|  - Tests E2E Playwright (si UI)           |
|  - Lint/Format automatique                |
|  - Review finale globale                  |
+-------------------------------------------+
          |
          v
+-------------------------------------------+
|  PHASE 6: MERGE & CLEANUP                 |
|  -----------------------------------      |
|  - Merge worktrees si utilises            |
|  - Resoudre conflits si besoin            |
|  - Cleanup worktrees                      |
|  - Rapport final                          |
+-------------------------------------------+
```

## Regles de dispatch automatique

### Quand utiliser des agents paralleles

```
PARALLELE si:
+-- Fichiers differents pour chaque tache
+-- Pas de dependance de donnees entre taches
+-- Pas d'etat partage
+-- Chaque tache peut etre testee independamment

SEQUENTIEL si:
+-- Fichiers partages
+-- Tache B depend du resultat de A
+-- Etat partage (DB, cache, config)
+-- Tests d'integration necessaires entre etapes
```

### Matrice de decision isolation

| Situation                     | Isolation | Methode            |
| ----------------------------- | --------- | ------------------ |
| 1 agent, 1-3 fichiers         | Non       | Direct             |
| 2+ agents, fichiers distincts | Non       | Parallel direct    |
| 2+ agents, fichiers partages  | Oui       | Worktrees          |
| Feature complete              | Oui       | Worktree unique    |
| Hotfix urgent                 | Non       | Direct sur branche |

## Template TaskList automatique

Pour une feature "Dashboard Analytics":

```
TaskCreate: "Creer les types TypeScript"
  scope: src/types/analytics.ts
  blockedBy: []

TaskCreate: "Creer les composants UI"
  scope: src/components/analytics/*
  blockedBy: [types]

TaskCreate: "Creer les API routes"
  scope: src/app/api/analytics/*
  blockedBy: [types]

TaskCreate: "Creer les tests"
  scope: src/__tests__/analytics/*
  blockedBy: [components, api]

TaskCreate: "Integration et verification"
  scope: *
  blockedBy: [tests]
```

---

## Debug Pattern: Dispatch Parallele

### Quand utiliser le pattern debug

```dot
digraph when_to_use {
    "Multiple failures?" [shape=diamond];
    "Are they independent?" [shape=diamond];
    "Single agent investigates all" [shape=box];
    "One agent per problem domain" [shape=box];
    "Can they work in parallel?" [shape=diamond];
    "Sequential agents" [shape=box];
    "Parallel dispatch" [shape=box];

    "Multiple failures?" -> "Are they independent?" [label="yes"];
    "Are they independent?" -> "Single agent investigates all" [label="no - related"];
    "Are they independent?" -> "Can they work in parallel?" [label="yes"];
    "Can they work in parallel?" -> "Parallel dispatch" [label="yes"];
    "Can they work in parallel?" -> "Sequential agents" [label="no - shared state"];
}
```

**Utiliser quand:**

- 3+ fichiers de test en echec avec causes differentes
- Plusieurs sous-systemes casses independamment
- Chaque probleme peut etre compris sans contexte des autres
- Pas d'etat partage entre investigations

**Ne pas utiliser quand:**

- Les failures sont liees (fixer une peut fixer les autres)
- Besoin de comprendre l'etat systeme complet
- Les agents intereferaient entre eux

### Processus debug parallele

1. **Identifier les domaines independants**
   - File A tests: Tool approval flow
   - File B tests: Batch completion behavior
   - File C tests: Abort functionality

2. **Creer des taches focalisees**
   - Scope specifique: Un fichier de test ou sous-systeme
   - Objectif clair: Faire passer ces tests
   - Contraintes: Ne pas changer autre code
   - Output attendu: Resume de ce qui a ete trouve et corrige

3. **Dispatcher en parallele**

   ```
   Task("Fix agent-tool-abort.test.ts failures")
   Task("Fix batch-completion-behavior.test.ts failures")
   Task("Fix tool-approval-race-conditions.test.ts failures")
   // Les trois tournent en parallele
   ```

4. **Review et integration**
   - Lire chaque resume
   - Verifier que les fixes ne conflictent pas
   - Lancer la suite de tests complete
   - Integrer tous les changements

### Erreurs communes debug

**X Trop large:** "Fix all the tests" - agent se perd
**V Specifique:** "Fix agent-tool-abort.test.ts" - scope focalise

**X Pas de contexte:** "Fix the race condition" - agent ne sait pas ou
**V Contexte:** Coller les messages d'erreur et noms de tests

**X Pas de contraintes:** Agent pourrait tout refactorer
**V Contraintes:** "Do NOT change production code" ou "Fix tests only"

**X Output vague:** "Fix it" - on ne sait pas ce qui a change
**V Specifique:** "Return summary of root cause and changes"

---

## Systeme de Review 2 Etapes

### Principe fondamental

**Fresh subagent par tache + review 2 etapes (spec puis qualite) = haute qualite, iteration rapide**

### Flow de review par tache

```
Subagent Implementeur
        |
        v
Implementation + tests + commit + self-review
        |
        v
+-------------------------------------------+
|  REVIEW ETAPE 1: SPEC COMPLIANCE          |
|  -----------------------------------      |
|  Subagent reviewer verifie:               |
|  - Implementation correspond au spec?     |
|  - Rien de manquant?                      |
|  - Rien de supplementaire non demande?    |
+-------------------------------------------+
        |
    +---+---+
    |       |
   OK      NOK --> Implementeur corrige --> Re-review spec
    |
    v
+-------------------------------------------+
|  REVIEW ETAPE 2: CODE QUALITY             |
|  -----------------------------------      |
|  Subagent reviewer verifie:               |
|  - Code propre et maintenable?            |
|  - Tests adequats?                        |
|  - Performance OK?                        |
|  - Securite OK?                           |
+-------------------------------------------+
        |
    +---+---+
    |       |
   OK      NOK --> Implementeur corrige --> Re-review qualite
    |
    v
Tache complete
```

### Regles strictes du systeme de review

**NEVER:**

- Commencer sur main/master sans consentement explicite
- Skip les reviews (spec compliance OU code quality)
- Continuer avec des issues non fixees
- Dispatcher plusieurs subagents implementation en parallele (conflits)
- Faire lire le fichier plan au subagent (fournir le texte complet)
- Ignorer les questions du subagent
- Accepter "presque bon" sur la spec compliance
- Skip les boucles de re-review
- Laisser la self-review remplacer la vraie review
- **Commencer la review qualite AVANT que la spec compliance soit OK**
- Passer a la tache suivante avec des issues ouvertes

**Si subagent pose des questions:**

- Repondre clairement et completement
- Fournir contexte additionnel si besoin
- Ne pas le presser vers l'implementation

**Si reviewer trouve des issues:**

- Implementeur (meme subagent) corrige
- Reviewer re-review
- Repeter jusqu'a approbation
- Ne pas skip la re-review

**Si subagent echoue une tache:**

- Dispatcher un subagent fix avec instructions specifiques
- Ne pas essayer de fixer manuellement (pollution du contexte)

---

## Verifications automatiques

### Avant chaque commit agent

```bash
# 1. Format
prettier --check "**/*.{ts,tsx,js,jsx}"
ruff check "**/*.py"

# 2. Types
npx tsc --noEmit

# 3. Lint
npx eslint . --ext .ts,.tsx

# 4. Tests unitaires
npm test -- --passWithNoTests

# 5. Build check
npm run build
```

### Apres merge multi-agent

```bash
# 1. Tests complets
npm test

# 2. Tests E2E
npx playwright test

# 3. Build final
npm run build

# 4. Type check global
npx tsc --noEmit
```

### Verification post-debug parallele

1. **Review chaque resume** - Comprendre ce qui a change
2. **Check les conflits** - Les agents ont-ils edite le meme code?
3. **Lancer suite complete** - Verifier que tous les fixes fonctionnent ensemble
4. **Spot check** - Les agents peuvent faire des erreurs systematiques

---

## Prompts Agents Standardises

Les templates complets sont dans `./prompts/`:

- `implementer-prompt.md` - Subagent implementation
- `spec-reviewer-prompt.md` - Review conformite spec
- `code-quality-reviewer-prompt.md` - Review qualite code

### Agent developpement (resume)

```markdown
## Contexte

Tu travailles sur: [FEATURE]
Ton scope est STRICTEMENT limite a: [FILES]
Ne modifie AUCUN fichier hors de ce scope.

## Tache

[DESCRIPTION COMPLETE - ne pas faire lire le fichier plan]

## Contraintes

- Scope: [FILES] uniquement
- Style: Suivre conventions existantes
- Types: TypeScript strict
- Tests: Creer/mettre a jour si necessaire

## Avant de commencer

Si tu as des questions sur les requirements, l'approche, ou quoi que ce soit
d'ambigu: **pose-les maintenant** avant de coder.

## Self-review obligatoire

Avant de reporter, verifie:

- Completude: tout le spec est implemente?
- Qualite: c'est ton meilleur travail?
- Discipline: pas de sur-engineering?
- Tests: ils verifient vraiment le comportement?

## Output attendu

1. Fichiers modifies/crees
2. Resume des changements
3. Tests passent: oui/non
4. Self-review findings
5. Problemes rencontres
```

### Agent test

```markdown
## Contexte

Tu testes: [FEATURE]
Code source: [FILES]

## Tache

1. Analyser le code a tester
2. Creer tests unitaires exhaustifs
3. Creer tests d'integration si API
4. Verifier edge cases

## Output attendu

1. Fichiers test crees
2. Couverture estimee
3. Tous tests passent: oui/non
4. Cas non couverts identifies
```

### Agent review spec compliance

```markdown
## Ce qui etait demande

[TEXTE COMPLET des requirements]

## Ce que l'implementeur pretend avoir construit

[Du rapport de l'implementeur]

## CRITIQUE: Ne pas faire confiance au rapport

L'implementeur a fini suspicieusement vite. Son rapport peut etre incomplet,
inexact, ou optimiste. Tu DOIS verifier tout independamment.

**NE PAS:**

- Croire sur parole ce qu'il a implemente
- Faire confiance a ses claims de completude
- Accepter son interpretation des requirements

**FAIRE:**

- Lire le code reel qu'il a ecrit
- Comparer implementation reelle vs requirements ligne par ligne
- Chercher les pieces manquantes qu'il pretend avoir implementees
- Chercher les features extras non mentionnees

## Report

- OK Spec compliant (si tout matche apres inspection du code)
- X Issues trouvees: [lister specifiquement ce qui manque ou est en trop, avec file:line]
```

### Agent review code quality

```markdown
Utiliser le template requesting-code-review/code-reviewer.md

WHAT_WAS_IMPLEMENTED: [du rapport implementeur]
PLAN_OR_REQUIREMENTS: Task N from [plan-file]
BASE_SHA: [commit avant tache]
HEAD_SHA: [commit actuel]
DESCRIPTION: [resume tache]

Code reviewer retourne: Strengths, Issues (Critical/Important/Minor), Assessment
```

---

## Securite

### Checks automatiques avant execution

1. **Scope validation**: Agent ne peut pas sortir de son scope
2. **Branch protection**: Jamais sur main/master
3. **Secrets scan**: Detection credentials avant commit
4. **Dangerous commands**: Bloques par hook

### Rollback automatique

Si une verification echoue:

1. Git stash des changements
2. Notification avec erreur detaillee
3. Attente instruction utilisateur

---

## Metriques de succes

Apres orchestration complete:

```
+========================================+
|         ORCHESTRATION COMPLETE         |
+========================================+
| Taches creees:     5                   |
| Agents lances:     3 (2 paralleles)    |
| Fichiers modifies: 12                  |
| Tests ajoutes:     8                   |
| Tests passent:     OK 47/47            |
| Type errors:       OK 0                |
| Build:             OK Success          |
| Reviews passed:    OK 5/5              |
| Temps total:       ~4 min              |
+========================================+
```

---

## Integration autres skills

| Skill                            | Quand appele                    |
| -------------------------------- | ------------------------------- |
| `brainstorming`                  | Phase 1 si feature complexe     |
| `writing-plans`                  | Phase 2 pour plan detaille      |
| `using-git-worktrees`            | Phase 3 si isolation necessaire |
| `test-driven-development`        | Subagents suivent TDD           |
| `requesting-code-review`         | Phase 4 review qualite          |
| `verification-before-completion` | Phase 5 obligatoire             |
| `security-review`                | Phase 5 si code sensible        |
| `finishing-a-development-branch` | Phase 6 pour merge              |

---

## Exemple complet: Feature avec review 2 etapes

```
User: Implementer Dashboard Analytics

[PHASE 1: Analyse]
- 5 taches identifiees
- Fichiers distincts -> parallel possible
- Pas d'etat partage

[PHASE 2: TaskList]
- Task 1: Types (scope: types/analytics.ts)
- Task 2: Components (scope: components/analytics/*, blocked by 1)
- Task 3: API (scope: app/api/analytics/*, blocked by 1)
- Task 4: Tests (blocked by 2,3)
- Task 5: Integration (blocked by 4)

[PHASE 4: Execution avec review 2 etapes]

--- Task 1: Types ---
[Dispatch implementeur avec texte complet]
Implementeur: "Question: les metrics doivent etre en real-time ou daily?"
Controller: "Daily, agrege chaque nuit"
Implementeur: "OK. Implementing..." [commit]

[Dispatch spec reviewer]
Spec reviewer: "OK Conforme - tous les types requis presents"

[Dispatch code quality reviewer]
Code reviewer: "Strengths: Types exhaustifs. Issues: None. Approved."

[Mark Task 1 complete]

--- Task 2: Components (parallel avec Task 3) ---
[Dispatch implementeur]
Implementeur: [implemente, commit]

[Dispatch spec reviewer]
Spec reviewer: "X Manquant: le loading skeleton demande dans spec"

[Implementeur corrige]
Implementeur: "Added loading skeleton" [commit]

[Re-review spec]
Spec reviewer: "OK Conforme maintenant"

[Dispatch code quality reviewer]
Code reviewer: "Issue Important: Magic number pour refresh interval"

[Implementeur corrige]
Implementeur: "Extracted REFRESH_INTERVAL constant" [commit]

[Re-review qualite]
Code reviewer: "OK Approved"

[Mark Task 2 complete]

... (continue pour autres taches)

[PHASE 5: Verification globale]
- tsc: OK
- tests: 47/47 OK
- build: OK

[PHASE 6: Merge & Rapport]
+========================================+
|         ORCHESTRATION COMPLETE         |
+========================================+
| Taches: 5/5 OK                         |
| Reviews: 10 (5 spec + 5 quality)       |
| Re-reviews: 3 (issues corrigees)       |
| Build: OK                              |
+========================================+
```

---

## Exemple debug parallele

**Scenario:** 6 test failures dans 3 fichiers apres refactoring majeur

**Failures:**

- agent-tool-abort.test.ts: 3 failures (timing issues)
- batch-completion-behavior.test.ts: 2 failures (tools not executing)
- tool-approval-race-conditions.test.ts: 1 failure (execution count = 0)

**Decision:** Domaines independants - abort logic / batch completion / race conditions

**Dispatch:**

```
Agent 1 -> Fix agent-tool-abort.test.ts
Agent 2 -> Fix batch-completion-behavior.test.ts
Agent 3 -> Fix tool-approval-race-conditions.test.ts
```

**Resultats:**

- Agent 1: Replaced timeouts with event-based waiting
- Agent 2: Fixed event structure bug (threadId in wrong place)
- Agent 3: Added wait for async tool execution to complete

**Integration:** Tous les fixes independants, pas de conflits, suite complete verte

**Temps economise:** 3 problemes resolus en parallele vs sequentiellement
