# Code Quality Reviewer Prompt Template

Use this template when dispatching a code quality reviewer subagent.

**Purpose:** Verify implementation is well-built (clean, tested, maintainable)

**Only dispatch after spec compliance review passes.**

```
Task tool (superpowers:code-reviewer):
  Use template at requesting-code-review/code-reviewer.md

  WHAT_WAS_IMPLEMENTED: [from implementer's report]
  PLAN_OR_REQUIREMENTS: Task N from [plan-file]
  BASE_SHA: [commit before task]
  HEAD_SHA: [current commit]
  DESCRIPTION: [task summary]
```

**Code reviewer returns:** Strengths, Issues (Critical/Important/Minor), Assessment

## Alternative: Inline Quality Review

If not using the code-reviewer skill template, use this prompt:

```
Task tool (general-purpose):
  description: "Code quality review for Task N"
  prompt: |
    You are reviewing code quality for a completed implementation.

    ## What Was Implemented

    [From implementer's report]

    ## Files Changed

    [List of files, or git diff reference]

    ## Your Job

    Review the implementation for quality, NOT spec compliance (already verified).

    **Code Quality:**
    - Is the code clean and readable?
    - Are names meaningful and consistent?
    - Is there unnecessary complexity?
    - Are there magic numbers or hardcoded values?

    **Testing:**
    - Are tests comprehensive?
    - Do they test behavior, not implementation details?
    - Are edge cases covered?
    - Would tests catch regressions?

    **Performance:**
    - Any obvious performance issues?
    - N+1 queries?
    - Unnecessary re-renders?
    - Memory leaks?

    **Security:**
    - Input validation?
    - SQL injection risks?
    - XSS vulnerabilities?
    - Exposed secrets?

    **Maintainability:**
    - Would a new developer understand this?
    - Is it following existing patterns?
    - Is it over-engineered?

    ## Report Format

    **Strengths:**
    - [What's good about this code]

    **Issues:**
    - Critical: [Must fix before merge]
    - Important: [Should fix, clear improvement]
    - Minor: [Nice to have, stylistic]

    **Assessment:**
    - OK Approved (no critical/important issues)
    - X Needs work: [specific fixes required]
```
