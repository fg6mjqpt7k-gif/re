---
name: git-workflow
description: Complete Git worktree workflow - covers the full development cycle from isolated workspace creation through implementation to merge/PR and cleanup
---

# Git Workflow

## Overview

Complete workflow for isolated feature development using Git worktrees. Covers the full cycle: create worktree -> develop -> integrate -> cleanup.

**Core principle:** Isolation + Safety verification + Clean integration = Reliable feature development.

**Announce at start:** "I'm using the git-workflow skill to [create an isolated workspace / complete this development work]."

---

## Section 1: Setup - Creating Worktrees

Git worktrees create isolated workspaces sharing the same repository, allowing work on multiple branches simultaneously without switching.

### 1.1 Directory Selection Process

Follow this priority order:

#### Check Existing Directories

```bash
# Check in priority order
ls -d .worktrees 2>/dev/null     # Preferred (hidden)
ls -d worktrees 2>/dev/null      # Alternative
```

**If found:** Use that directory. If both exist, `.worktrees` wins.

#### Check CLAUDE.md

```bash
grep -i "worktree.*director" CLAUDE.md 2>/dev/null
```

**If preference specified:** Use it without asking.

#### Ask User

If no directory exists and no CLAUDE.md preference:

```
No worktree directory found. Where should I create worktrees?

1. .worktrees/ (project-local, hidden)
2. ~/.config/superpowers/worktrees/<project-name>/ (global location)

Which would you prefer?
```

### 1.2 Safety Verification

#### For Project-Local Directories (.worktrees or worktrees)

**MUST verify directory is ignored before creating worktree:**

```bash
# Check if directory is ignored (respects local, global, and system gitignore)
git check-ignore -q .worktrees 2>/dev/null || git check-ignore -q worktrees 2>/dev/null
```

**If NOT ignored:**

1. Add appropriate line to .gitignore
2. Commit the change
3. Proceed with worktree creation

**Why critical:** Prevents accidentally committing worktree contents to repository.

#### For Global Directory (~/.config/superpowers/worktrees)

No .gitignore verification needed - outside project entirely.

### 1.3 Worktree Creation Steps

#### 1. Detect Project Name

```bash
project=$(basename "$(git rev-parse --show-toplevel)")
```

#### 2. Create Worktree

```bash
# Determine full path
case $LOCATION in
  .worktrees|worktrees)
    path="$LOCATION/$BRANCH_NAME"
    ;;
  ~/.config/superpowers/worktrees/*)
    path="~/.config/superpowers/worktrees/$project/$BRANCH_NAME"
    ;;
esac

# Create worktree with new branch
git worktree add "$path" -b "$BRANCH_NAME"
cd "$path"
```

#### 3. Run Project Setup

Auto-detect and run appropriate setup:

```bash
# Node.js
if [ -f package.json ]; then npm install; fi

# Rust
if [ -f Cargo.toml ]; then cargo build; fi

# Python
if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
if [ -f pyproject.toml ]; then poetry install; fi

# Go
if [ -f go.mod ]; then go mod download; fi
```

#### 4. Verify Clean Baseline

Run tests to ensure worktree starts clean:

```bash
# Examples - use project-appropriate command
npm test
cargo test
pytest
go test ./...
```

**If tests fail:** Report failures, ask whether to proceed or investigate.

**If tests pass:** Report ready.

#### 5. Report Location

```
Worktree ready at <full-path>
Tests passing (<N> tests, 0 failures)
Ready to implement <feature-name>
```

### 1.4 Setup Quick Reference

| Situation                  | Action                      |
| -------------------------- | --------------------------- |
| `.worktrees/` exists       | Use it (verify ignored)     |
| `worktrees/` exists        | Use it (verify ignored)     |
| Both exist                 | Use `.worktrees/`           |
| Neither exists             | Check CLAUDE.md -> Ask user |
| Directory not ignored      | Add to .gitignore + commit  |
| Tests fail during baseline | Report failures + ask       |
| No package.json/Cargo.toml | Skip dependency install     |

---

## Section 2: Development - Working in Worktrees

### 2.1 Development Best Practices

While working in a worktree:

- **Stay in the worktree directory** - All changes happen in isolation
- **Commit frequently** - Small, atomic commits are easier to review
- **Keep the feature branch focused** - One feature per worktree
- **Run tests after each significant change** - Catch issues early

### 2.2 Syncing with Base Branch

If the base branch has updates during development:

```bash
# From the worktree
git fetch origin
git rebase origin/<base-branch>  # or merge if preferred
```

**After rebase/merge:** Re-run tests to verify no conflicts broke anything.

### 2.3 Multiple Worktrees

List all worktrees:

```bash
git worktree list
```

Switch between worktrees by changing directories - no branch switching needed.

### 2.4 Common Development Issues

| Issue                                | Solution                                |
| ------------------------------------ | --------------------------------------- |
| Need to see main branch code         | `git show main:path/to/file`            |
| Accidentally edited wrong worktree   | Stash and apply to correct one          |
| Need shared changes across worktrees | Commit, push, pull in other worktree    |
| Worktree shows wrong branch          | Check `git worktree list`, remove stale |

---

## Section 3: Completion - Finishing Branch

Guide completion of development work by presenting clear options and handling chosen workflow.

### 3.1 Verify Tests

**Before presenting options, verify tests pass:**

```bash
# Run project's test suite
npm test / cargo test / pytest / go test ./...
```

**If tests fail:**

```
Tests failing (<N> failures). Must fix before completing:

[Show failures]

Cannot proceed with merge/PR until tests pass.
```

Stop. Don't proceed to Step 3.2.

**If tests pass:** Continue to Step 3.2.

### 3.2 Determine Base Branch

```bash
# Try common base branches
git merge-base HEAD main 2>/dev/null || git merge-base HEAD master 2>/dev/null
```

Or ask: "This branch split from main - is that correct?"

### 3.3 Present Options

Present exactly these 4 options:

```
Implementation complete. What would you like to do?

1. Merge back to <base-branch> locally
2. Push and create a Pull Request
3. Keep the branch as-is (I'll handle it later)
4. Discard this work

Which option?
```

**Don't add explanation** - keep options concise.

### 3.4 Execute Choice

#### Option 1: Merge Locally

```bash
# Switch to base branch
git checkout <base-branch>

# Pull latest
git pull

# Merge feature branch
git merge <feature-branch>

# Verify tests on merged result
<test command>

# If tests pass
git branch -d <feature-branch>
```

Then: Cleanup worktree (Step 3.5)

#### Option 2: Push and Create PR

```bash
# Push branch
git push -u origin <feature-branch>

# Create PR
gh pr create --title "<title>" --body "$(cat <<'EOF'
## Summary
<2-3 bullets of what changed>

## Test Plan
- [ ] <verification steps>
EOF
)"
```

Then: Cleanup worktree (Step 3.5)

#### Option 3: Keep As-Is

Report: "Keeping branch <name>. Worktree preserved at <path>."

**Don't cleanup worktree.**

#### Option 4: Discard

**Confirm first:**

```
This will permanently delete:
- Branch <name>
- All commits: <commit-list>
- Worktree at <path>

Type 'discard' to confirm.
```

Wait for exact confirmation.

If confirmed:

```bash
git checkout <base-branch>
git branch -D <feature-branch>
```

Then: Cleanup worktree (Step 3.5)

### 3.5 Cleanup Worktree

**For Options 1, 2, 4:**

Check if in worktree:

```bash
git worktree list | grep $(git branch --show-current)
```

If yes:

```bash
git worktree remove <worktree-path>
```

**For Option 3:** Keep worktree.

### 3.6 Completion Quick Reference

| Option           | Merge | Push | Keep Worktree | Cleanup Branch |
| ---------------- | ----- | ---- | ------------- | -------------- |
| 1. Merge locally | Yes   | -    | -             | Yes            |
| 2. Create PR     | -     | Yes  | Yes           | -              |
| 3. Keep as-is    | -     | -    | Yes           | -              |
| 4. Discard       | -     | -    | -             | Yes (force)    |

---

## Full Workflow Example

```
You: I'm using the git-workflow skill to set up an isolated workspace.

[Check .worktrees/ - exists]
[Verify ignored - git check-ignore confirms .worktrees/ is ignored]
[Create worktree: git worktree add .worktrees/auth -b feature/auth]
[Run npm install]
[Run npm test - 47 passing]

Worktree ready at /Users/dev/myproject/.worktrees/auth
Tests passing (47 tests, 0 failures)
Ready to implement auth feature

--- DEVELOPMENT PHASE ---

[Implement feature...]
[Commit changes...]
[Run tests - 52 passing]

--- COMPLETION PHASE ---

You: I'm using the git-workflow skill to complete this development work.

[Run npm test - 52 passing]

Implementation complete. What would you like to do?

1. Merge back to main locally
2. Push and create a Pull Request
3. Keep the branch as-is (I'll handle it later)
4. Discard this work

Which option?

User: 2

[git push -u origin feature/auth]
[gh pr create --title "Add authentication feature" --body "..."]

PR created: https://github.com/org/repo/pull/42
Branch pushed. Worktree preserved at /Users/dev/myproject/.worktrees/auth
```

---

## Common Mistakes

### Setup Phase

| Mistake                    | Problem                                    | Fix                                         |
| -------------------------- | ------------------------------------------ | ------------------------------------------- |
| Skip ignore verification   | Worktree contents pollute git status       | Always use `git check-ignore`               |
| Assume directory location  | Inconsistency, violates conventions        | Follow priority: existing > CLAUDE.md > ask |
| Proceed with failing tests | Can't distinguish new vs pre-existing bugs | Report failures, get permission             |
| Hardcode setup commands    | Breaks on different project tools          | Auto-detect from project files              |

### Completion Phase

| Mistake                 | Problem                              | Fix                            |
| ----------------------- | ------------------------------------ | ------------------------------ |
| Skip test verification  | Merge broken code, create failing PR | Always verify tests first      |
| Open-ended questions    | "What next?" is ambiguous            | Present exactly 4 options      |
| Auto worktree cleanup   | Remove worktree when might need it   | Only cleanup for Options 1 & 4 |
| No discard confirmation | Accidentally delete work             | Require typed "discard"        |

---

## Red Flags

**Never:**

- Create worktree without verifying it's ignored (project-local)
- Skip baseline test verification
- Proceed with failing tests without asking
- Assume directory location when ambiguous
- Skip CLAUDE.md check
- Merge without verifying tests on result
- Delete work without confirmation
- Force-push without explicit request

**Always:**

- Follow directory priority: existing > CLAUDE.md > ask
- Verify directory is ignored for project-local
- Auto-detect and run project setup
- Verify clean test baseline
- Present exactly 4 completion options
- Get typed confirmation for discard
- Clean up worktree for Options 1 & 4 only

---

## Integration

**Called by:**

- **brainstorming** (Phase 4) - REQUIRED when design is approved and implementation follows
- **subagent-driven-development** - REQUIRED before executing any tasks
- **executing-plans** - REQUIRED before executing any tasks
- Any skill needing isolated workspace

**Replaces:**

- **using-git-worktrees** - Section 1 (Setup)
- **finishing-a-development-branch** - Section 3 (Completion)
