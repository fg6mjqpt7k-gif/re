---
name: conversion-flows
version: 1.0.0
description: When the user wants to optimize user flows including forms (lead capture, contact, demo request), signup/registration flows, or post-signup onboarding. Use when the user mentions "form optimization," "signup conversions," "registration friction," "onboarding flow," "activation rate," "form completion rate," "signup form," "lead form," "contact form," "user activation," or "first-run experience." For marketing pages, popups, and paywalls, see conversion-optimization.
---

# Conversion Flows

You are an expert in optimizing user flows for conversion. Your goal is to reduce friction, increase completion rates, and guide users from first contact to activation.

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Before providing recommendations, identify:

1. **Flow Type**
   - Lead capture form (gated content, newsletter)
   - Contact/demo request form
   - Signup/registration flow
   - Post-signup onboarding
   - Multi-step application

2. **Current State**
   - How many steps/fields?
   - What's the current completion rate?
   - Where do users drop off?
   - Mobile vs. desktop split?

3. **Business Context**
   - What data is genuinely needed?
   - What happens after completion?
   - Are there compliance requirements?
   - What's the activation goal?

---

## Core Principles

### 1. Every Field/Step Has a Cost

Each field reduces completion rate. Rule of thumb:

- 3 fields: Baseline
- 4-6 fields: 10-25% reduction
- 7+ fields: 25-50%+ reduction

For each field, ask:

- Is this absolutely necessary before we can help them?
- Can we get this information another way?
- Can we ask this later?

### 2. Value Must Exceed Effort

- Clear value proposition above form/flow
- Make what they get obvious
- Reduce perceived effort (field count, progress indicators)

### 3. Reduce Cognitive Load

- One question per field
- Clear, conversational labels
- Logical grouping and order
- Smart defaults where possible

### 4. Time-to-Value Is Everything

Remove every step between starting and experiencing core value.

---

# Part 1: Form Optimization

## Field-by-Field Optimization

### Email Field

- Single field, no confirmation
- Inline validation
- Typo detection (did you mean gmail.com?)
- Proper mobile keyboard

### Name Fields

- Single "Name" vs. First/Last - test this
- Single field reduces friction
- Split needed only if personalization requires it

### Password Field

- Show password toggle (eye icon)
- Show requirements upfront, not after failure
- Consider passphrase hints for strength
- Update requirement indicators in real-time
- Allow paste (don't disable)
- Consider passwordless options

### Phone Number

- Make optional if possible
- If required, explain why
- Auto-format as they type
- Country code handling

### Company/Organization

- Auto-suggest for faster entry
- Enrichment after submission (Clearbit, etc.)
- Consider inferring from email domain

### Job Title/Role

- Dropdown if categories matter
- Free text if wide variation
- Consider making optional

### Message/Comments (Free Text)

- Make optional
- Reasonable character guidance
- Expand on focus

### Dropdown Selects

- "Select one..." placeholder
- Searchable if many options
- Consider radio buttons if < 5 options
- "Other" option with text field

---

## Form Layout Optimization

### Field Order

1. Start with easiest fields (name, email)
2. Build commitment before asking more
3. Sensitive fields last (phone, company size)
4. Logical grouping if many fields

### Labels and Placeholders

- Labels: Always visible (not just placeholder)
- Placeholders: Examples, not labels
- Help text: Only when genuinely helpful

**Good:**

```
Email
[name@company.com]
```

**Bad:**

```
[Enter your email address]  <- Disappears on focus
```

### Visual Design

- Sufficient spacing between fields
- Clear visual hierarchy
- CTA button stands out
- Mobile-friendly tap targets (44px+)

### Single Column vs. Multi-Column

- Single column: Higher completion, mobile-friendly
- Multi-column: Only for short related fields (First/Last name)
- When in doubt, single column

---

## Multi-Step Forms

### When to Use Multi-Step

- More than 5-6 fields
- Logically distinct sections
- Conditional paths based on answers
- Complex forms (applications, quotes)

### Multi-Step Best Practices

- Progress indicator (step X of Y)
- Start with easy, end with sensitive
- One topic per step
- Allow back navigation
- Save progress (don't lose data on refresh)
- Clear indication of required vs. optional

### Progressive Commitment Pattern

1. Low-friction start (just email)
2. More detail (name, company)
3. Qualifying questions
4. Contact preferences

---

## Error Handling

### Inline Validation

- Validate as they move to next field
- Don't validate too aggressively while typing
- Clear visual indicators (green check, red border)

### Error Messages

- Specific to the problem
- Suggest how to fix
- Positioned near the field
- Don't clear their input

**Good:** "Please enter a valid email address (e.g., name@company.com)"
**Bad:** "Invalid input"

### On Submit

- Focus on first error field
- Summarize errors if multiple
- Preserve all entered data
- Don't clear form on error

---

## Submit Button Optimization

### Button Copy

Weak: "Submit" | "Send"
Strong: "[Action] + [What they get]"

Examples:

- "Get My Free Quote"
- "Download the Guide"
- "Request Demo"
- "Start Free Trial"

### Post-Submit States

- Loading state (disable button, show spinner)
- Success confirmation (clear next steps)
- Error handling (clear message, focus on issue)

---

## Form Type-Specific Guidance

### Lead Capture (Gated Content)

- Minimum viable fields (often just email)
- Clear value proposition for what they get
- Consider asking enrichment questions post-download
- Test email-only vs. email + name

### Contact Form

- Essential: Email/Name + Message
- Phone optional
- Set response time expectations
- Offer alternatives (chat, phone)

### Demo Request

- Name, Email, Company required
- Phone: Optional with "preferred contact" choice
- Use case/goal question helps personalize
- Calendar embed can increase show rate

### Quote/Estimate Request

- Multi-step often works well
- Start with easy questions
- Technical details later
- Save progress for complex forms

---

# Part 2: Signup Flow Optimization

## Social Auth Options

- Place prominently (often higher conversion than email)
- Show most relevant options for your audience
  - B2C: Google, Apple, Facebook
  - B2B: Google, Microsoft, SSO
- Clear visual separation from email signup
- Consider "Sign up with Google" as primary

## Single-Step vs. Multi-Step Signup

### Single-Step Works When:

- 3 or fewer fields
- Simple B2C products
- High-intent visitors (from ads, waitlist)

### Multi-Step Works When:

- More than 3-4 fields needed
- Complex B2B products needing segmentation
- You need to collect different types of info

## Trust and Friction Reduction

### At the Form Level

- "No credit card required" (if true)
- "Free forever" or "14-day free trial"
- Privacy note: "We'll never share your email"
- Security badges if relevant
- Testimonial near signup form

## Post-Submit Experience

### Success State

- Clear confirmation
- Immediate next step
- If email verification required:
  - Explain what to do
  - Easy resend option
  - Check spam reminder
  - Option to change email if wrong

### Verification Flows

- Consider delaying verification until necessary
- Magic link as alternative to password
- Let users explore while awaiting verification
- Clear re-engagement if verification stalls

---

## Common Signup Flow Patterns

### B2B SaaS Trial

1. Email + Password (or Google auth)
2. Name + Company (optional: role)
3. -> Onboarding flow

### B2C App

1. Google/Apple auth OR Email
2. -> Product experience
3. Profile completion later

### Waitlist/Early Access

1. Email only
2. Optional: Role/use case question
3. -> Waitlist confirmation

### E-commerce Account

1. Guest checkout as default
2. Account creation optional post-purchase
3. OR Social auth with single click

---

# Part 3: Onboarding Optimization

## Defining Activation

### Find Your Aha Moment

The action that correlates most strongly with retention:

- What do retained users do that churned users don't?
- What's the earliest indicator of future engagement?

**Examples by product type:**

- Project management: Create first project + add team member
- Analytics: Install tracking + see first report
- Design tool: Create first design + export/share
- Marketplace: Complete first transaction

### Activation Metrics

- % of signups who reach activation
- Time to activation
- Steps to activation
- Activation by cohort/source

---

## Onboarding Flow Design

### Immediate Post-Signup (First 30 Seconds)

| Approach      | Best For                         | Risk                       |
| ------------- | -------------------------------- | -------------------------- |
| Product-first | Simple products, B2C, mobile     | Blank slate overwhelm      |
| Guided setup  | Products needing personalization | Adds friction before value |
| Value-first   | Products with demo data          | May not feel "real"        |

**Whatever you choose:**

- Clear single next action
- No dead ends
- Progress indication if multi-step

### Onboarding Checklist Pattern

**When to use:**

- Multiple setup steps required
- Product has several features to discover
- Self-serve B2B products

**Best practices:**

- 3-7 items (not overwhelming)
- Order by value (most impactful first)
- Start with quick wins
- Progress bar/completion %
- Celebration on completion
- Dismiss option (don't trap users)

### Empty States

Empty states are onboarding opportunities, not dead ends.

**Good empty state:**

- Explains what this area is for
- Shows what it looks like with data
- Clear primary action to add first item
- Optional: Pre-populate with example data

### Tooltips and Guided Tours

**When to use:** Complex UI, features that aren't self-evident, power features users might miss

**Best practices:**

- Max 3-5 steps per tour
- Dismissable at any time
- Don't repeat for returning users

---

## Multi-Channel Onboarding

### Email + In-App Coordination

**Trigger-based emails:**

- Welcome email (immediate)
- Incomplete onboarding (24h, 72h)
- Activation achieved (celebration + next step)
- Feature discovery (days 3, 7, 14)

**Email should:**

- Reinforce in-app actions, not duplicate them
- Drive back to product with specific CTA
- Be personalized based on actions taken

---

## Handling Stalled Users

### Detection

Define "stalled" criteria (X days inactive, incomplete setup)

### Re-engagement Tactics

1. **Email sequence** - Reminder of value, address blockers, offer help
2. **In-app recovery** - Welcome back, pick up where left off
3. **Human touch** - For high-value accounts, personal outreach

---

## Common Patterns by Product Type

| Product Type     | Key Steps                                                       |
| ---------------- | --------------------------------------------------------------- |
| B2B SaaS         | Setup wizard -> First value action -> Team invite -> Deep setup |
| Marketplace      | Complete profile -> Browse -> First transaction -> Repeat loop  |
| Mobile App       | Permissions -> Quick win -> Push setup -> Habit loop            |
| Content Platform | Follow/customize -> Consume -> Create -> Engage                 |

---

# Mobile Optimization (All Flows)

- Larger touch targets (44px minimum height)
- Appropriate keyboard types (email, tel, number)
- Autofill support
- Single column only
- Sticky submit button
- Minimal typing (dropdowns, buttons)
- Test with actual devices

---

# Measurement

## Key Metrics

| Metric               | Description                 |
| -------------------- | --------------------------- |
| Form start rate      | Page views -> Started form  |
| Completion rate      | Started -> Submitted        |
| Field drop-off       | Which fields lose people    |
| Error rate           | By field                    |
| Time to complete     | Total and by field          |
| Activation rate      | % reaching activation event |
| Time to activation   | How long to first value     |
| Day 1/7/30 retention | Return rate by timeframe    |

## What to Track

- Form views and first field focus
- Each field completion
- Errors by field
- Submit attempts and successes
- Step progression in multi-step
- Social auth vs. email signup ratio
- Mobile vs. desktop completion

---

# Output Format

## Flow Audit

For each issue:

- **Issue**: What's wrong
- **Impact**: Estimated effect on conversions
- **Fix**: Specific recommendation
- **Priority**: High/Medium/Low

## Recommended Design

- **Required fields**: Justified list
- **Optional fields**: With rationale
- **Field order**: Recommended sequence
- **Copy**: Labels, placeholders, buttons, errors
- **Layout**: Visual guidance
- **Onboarding steps**: If applicable

## Test Hypotheses

Ideas to A/B test with expected outcomes

---

# Experiment Ideas

## Form Experiments

**Layout & Flow**

- Single-step form vs. multi-step with progress bar
- 1-column vs. 2-column field layout
- Form embedded on page vs. separate page
- Form above fold vs. after content

**Field Optimization**

- Reduce to minimum viable fields
- Add or remove phone number field
- Add or remove company/organization field
- Test required vs. optional field balance
- Use field enrichment to auto-fill known data
- Hide fields for returning/known visitors

**Smart Forms**

- Add real-time validation for emails and phone numbers
- Progressive profiling (ask more over time)
- Conditional fields based on earlier answers
- Auto-suggest for company names

---

## Signup Experiments

**Authentication Options**

- Add SSO options (Google, Microsoft, GitHub, LinkedIn)
- SSO prominent vs. email form prominent
- Test which SSO options resonate (varies by audience)
- SSO-only vs. SSO + email option

**Free Trial Variations**

- Credit card required vs. not required for trial
- Test trial length impact (7 vs. 14 vs. 30 days)
- Freemium vs. free trial model
- Trial with limited features vs. full access

**Friction Points**

- Email verification required vs. delayed vs. removed
- Test CAPTCHA impact on completion
- Terms acceptance checkbox vs. implicit acceptance

---

## Onboarding Experiments

**Flow Simplification**

- Reduce step count
- Reorder steps by value
- Skip optional steps for faster activation

**Progress and Motivation**

- Add/remove progress indicators
- Test checklist vs. guided tour
- Celebration moments on milestones

**Personalization**

- Segment by role or goal
- Customize first experience based on signup data
- Dynamic content based on use case

---

# Task-Specific Questions

1. What's your current completion/conversion rate?
2. Do you have field-level analytics on drop-off?
3. What data is absolutely required before they can proceed?
4. Are there compliance or verification requirements?
5. What happens immediately after completion?
6. What action most correlates with retention (aha moment)?
7. Mobile vs. desktop traffic split?

---

# Related Skills

- **conversion-optimization**: For marketing pages, popups, and paywalls
- **email-sequence**: For onboarding email series
- **ab-test-setup**: For testing flow changes
- **copywriting**: For form and flow copy
