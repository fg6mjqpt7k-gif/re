---
name: conversion-optimization
version: 2.0.0
description: "Complete CRO skill for all conversion optimization. Covers: (1) Marketing pages (homepage, landing, pricing, feature), (2) Popups/modals (email capture, exit intent), (3) Paywalls/upgrade screens, (4) Forms (lead capture, contact, demo request), (5) Signup/registration flows, (6) Post-signup onboarding. Triggers: CRO, conversion rate, page conversions, popup optimization, exit intent, paywall, upgrade screen, form optimization, signup conversions, registration friction, onboarding flow, activation rate, user activation, first-run experience."
---

# Conversion Optimization

Complete CRO skill covering the full conversion funnel: pages, popups, paywalls, forms, signup, and onboarding.

## Skill Organization

| Part       | Coverage          | Use For                                      |
| ---------- | ----------------- | -------------------------------------------- |
| **Part 1** | Page CRO          | Homepage, landing, pricing, feature pages    |
| **Part 2** | Popup CRO         | Email capture, exit intent, announcements    |
| **Part 3** | Paywall CRO       | Feature gates, usage limits, upgrade screens |
| **Part 4** | Form Optimization | Lead capture, contact, demo request forms    |
| **Part 5** | Signup Flows      | Registration, social auth, multi-step signup |
| **Part 6** | Onboarding        | Post-signup activation, checklists, tooltips |

**For detailed Form/Signup/Onboarding content:** See `references/conversion-flows.md`

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions.

Before providing recommendations, identify:

1. **Element Type**
   - Marketing page (homepage, landing, pricing, feature, blog)
   - Popup/modal (email capture, lead magnet, exit intent, announcement)
   - In-app paywall (feature gate, usage limit, trial expiration, upgrade prompt)
   - Form (lead capture, contact, demo request)
   - Signup/registration flow
   - Post-signup onboarding

2. **Conversion Goal**
   - Sign up, request demo, purchase, subscribe
   - Email capture, lead magnet download
   - Free to paid conversion, tier upgrade
   - Form completion, activation

3. **Traffic/User Context**
   - Where are visitors coming from? (organic, paid, email, social)
   - New vs. returning visitors
   - What have they already experienced?

---

## Core Principles

### 1. Value Proposition Clarity

Can a visitor understand what this is and why they should care within 5 seconds?

### 2. Single Clear Action

Is there one obvious primary action? Competing CTAs kill conversions.

### 3. Trust Before Ask

Social proof, testimonials, and guarantees reduce perceived risk.

### 4. Respect the User

Don't trap, trick, or annoy. Maintain trust for future conversion.

---

# Part 1: Page CRO

## CRO Analysis Framework

Analyze pages across these dimensions, in order of impact:

### 1. Value Proposition Clarity (Highest Impact)

**Check for:**

- Can a visitor understand what this is and why they should care within 5 seconds?
- Is the primary benefit clear, specific, and differentiated?
- Is it written in the customer's language (not company jargon)?

**Common issues:**

- Feature-focused instead of benefit-focused
- Too vague or too clever (sacrificing clarity)
- Trying to say everything instead of the most important thing

### 2. Headline Effectiveness

**Evaluate:**

- Does it communicate the core value proposition?
- Is it specific enough to be meaningful?
- Does it match the traffic source's messaging?

**Strong headline patterns:**

- Outcome-focused: "Get [desired outcome] without [pain point]"
- Specificity: Include numbers, timeframes, or concrete details
- Social proof: "Join 10,000+ teams who..."

### 3. CTA Placement, Copy, and Hierarchy

**Primary CTA assessment:**

- Is there one clear primary action?
- Is it visible without scrolling?
- Does the button copy communicate value, not just action?
  - Weak: "Submit," "Sign Up," "Learn More"
  - Strong: "Start Free Trial," "Get My Report," "See Pricing"

**CTA hierarchy:**

- Is there a logical primary vs. secondary CTA structure?
- Are CTAs repeated at key decision points?

### 4. Visual Hierarchy and Scannability

**Check:**

- Can someone scanning get the main message?
- Are the most important elements visually prominent?
- Is there enough white space?
- Do images support or distract from the message?

### 5. Trust Signals and Social Proof

**Types to look for:**

- Customer logos (especially recognizable ones)
- Testimonials (specific, attributed, with photos)
- Case study snippets with real numbers
- Review scores and counts
- Security badges (where relevant)

**Placement:** Near CTAs and after benefit claims

### 6. Objection Handling

**Common objections to address:**

- Price/value concerns
- "Will this work for my situation?"
- Implementation difficulty
- "What if it doesn't work?"

**Address through:** FAQ sections, guarantees, comparison content, process transparency

### 7. Friction Points

**Look for:**

- Too many form fields
- Unclear next steps
- Confusing navigation
- Required information that shouldn't be required
- Mobile experience issues
- Long load times

---

## Page-Specific Frameworks

### Homepage CRO

- Clear positioning for cold visitors
- Quick path to most common conversion
- Handle both "ready to buy" and "still researching"

### Landing Page CRO

- Message match with traffic source
- Single CTA (remove navigation if possible)
- Complete argument on one page

### Pricing Page CRO

- Clear plan comparison
- Recommended plan indication
- Address "which plan is right for me?" anxiety

### Feature Page CRO

- Connect feature to benefit
- Use cases and examples
- Clear path to try/buy

### Blog Post CRO

- Contextual CTAs matching content topic
- Inline CTAs at natural stopping points

---

# Part 2: Popup CRO

## Trigger Strategies

### Time-Based

- **Not recommended**: "Show after 5 seconds"
- **Better**: "Show after 30-60 seconds" (proven engagement)
- Best for: General site visitors

### Scroll-Based

- **Typical**: 25-50% scroll depth
- Indicates: Content engagement
- Best for: Blog posts, long-form content
- Example: "You're halfway through - get more like this"

### Exit Intent

- Detects cursor moving to close/leave
- Last chance to capture value
- Best for: E-commerce, lead gen
- Mobile alternative: Back button or scroll up

### Click-Triggered

- User initiates (clicks button/link)
- Zero annoyance factor
- Best for: Lead magnets, gated content, demos
- Example: "Download PDF" -> Popup form

### Page Count / Session-Based

- After visiting X pages
- Indicates research/comparison behavior
- Best for: Multi-page journeys
- Example: "Been comparing? Here's a summary..."

### Behavior-Based

- Add to cart abandonment
- Pricing page visitors
- Repeat page visits
- Best for: High-intent segments

---

## Popup Types

### Email Capture Popup

**Goal**: Newsletter/list subscription

**Best practices:**

- Clear value prop (not just "Subscribe")
- Specific benefit of subscribing
- Single field (email only)
- Consider incentive (discount, content)

**Copy structure:**

- Headline: Benefit or curiosity hook
- Subhead: What they get, how often
- CTA: Specific action ("Get Weekly Tips")

### Lead Magnet Popup

**Goal**: Exchange content for email

**Best practices:**

- Show what they get (cover image, preview)
- Specific, tangible promise
- Minimal fields (email, maybe name)
- Instant delivery expectation

### Discount/Promotion Popup

**Goal**: First purchase or conversion

**Best practices:**

- Clear discount (10%, $20, free shipping)
- Deadline creates urgency
- Single use per visitor
- Easy to apply code

### Exit Intent Popup

**Goal**: Last-chance conversion

**Best practices:**

- Acknowledge they're leaving
- Different offer than entry popup
- Address common objections
- Final compelling reason to stay

**Formats:**

- "Wait! Before you go..."
- "Forget something?"
- "Get 10% off your first order"
- "Questions? Chat with us"

### Announcement Banner

**Goal**: Site-wide communication

**Best practices:**

- Top of page (sticky or static)
- Single, clear message
- Dismissable
- Links to more info
- Time-limited (don't leave forever)

### Slide-In

**Goal**: Less intrusive engagement

**Best practices:**

- Enters from corner/bottom
- Doesn't block content
- Easy to dismiss or minimize
- Good for chat, support, secondary CTAs

---

## Popup Design Best Practices

### Visual Hierarchy

1. Headline (largest, first seen)
2. Value prop/offer (clear benefit)
3. Form/CTA (obvious action)
4. Close option (easy to find)

### Sizing

- Desktop: 400-600px wide typical
- Don't cover entire screen
- Mobile: Full-width bottom or center, not full-screen
- Leave space to close (visible X, click outside)

### Close Button

- Always visible (top right is convention)
- Large enough to tap on mobile
- "No thanks" text link as alternative
- Click outside to close

### Mobile Considerations

- Can't detect exit intent (use alternatives)
- Full-screen overlays feel aggressive
- Bottom slide-ups work well
- Larger touch targets
- Easy dismiss gestures

---

## Popup Copy Formulas

### Headlines

- Benefit-driven: "Get [result] in [timeframe]"
- Question: "Want [desired outcome]?"
- Command: "Don't miss [thing]"
- Social proof: "Join [X] people who..."
- Curiosity: "The one thing [audience] always get wrong about [topic]"

### CTA Buttons

- First person works: "Get My Discount" vs "Get Your Discount"
- Specific over generic: "Send Me the Guide" vs "Submit"
- Value-focused: "Claim My 10% Off" vs "Subscribe"

### Decline Options

- Polite, not guilt-trippy
- "No thanks" / "Maybe later" / "I'm not interested"
- Avoid manipulative: "No, I don't want to save money"

---

## Frequency and Rules

### Frequency Capping

- Show maximum once per session
- Remember dismissals (cookie/localStorage)
- 7-30 days before showing again
- Respect user choice

### Audience Targeting

- New vs. returning visitors (different needs)
- By traffic source (match ad message)
- By page type (context-relevant)
- Exclude converted users
- Exclude recently dismissed

### Page Rules

- Exclude checkout/conversion flows
- Consider blog vs. product pages
- Match offer to page context

---

## Compliance and Accessibility

### GDPR/Privacy

- Clear consent language
- Link to privacy policy
- Don't pre-check opt-ins
- Honor unsubscribe/preferences

### Accessibility

- Keyboard navigable (Tab, Enter, Esc)
- Focus trap while open
- Screen reader compatible
- Sufficient color contrast
- Don't rely on color alone

### Google Guidelines

- Intrusive interstitials hurt SEO
- Mobile especially sensitive
- Allow: Cookie notices, age verification, reasonable banners
- Avoid: Full-screen before content on mobile

---

# Part 3: Paywall and Upgrade CRO

## Paywall Trigger Points

### Feature Gates

When user clicks a paid-only feature:

- Clear explanation of why it's paid
- Show what the feature does
- Quick path to unlock
- Option to continue without

### Usage Limits

When user hits a limit:

- Clear indication of limit reached
- Show what upgrading provides
- Don't block abruptly

### Trial Expiration

When trial is ending:

- Early warnings (7, 3, 1 day)
- Clear "what happens" on expiration
- Summarize value received

### Time-Based Prompts

After X days of free use:

- Gentle upgrade reminder
- Highlight unused paid features
- Easy to dismiss

---

## Paywall Screen Components

1. **Headline** - Focus on what they get: "Unlock [Feature] to [Benefit]"

2. **Value Demonstration** - Preview, before/after, "With Pro you could..."

3. **Feature Comparison** - Highlight key differences, current plan marked

4. **Pricing** - Clear, simple, annual vs. monthly options

5. **Social Proof** - Customer quotes, "X teams use this"

6. **CTA** - Specific and value-oriented: "Start Getting [Benefit]"

7. **Escape Hatch** - Clear "Not now" or "Continue with Free"

---

## Specific Paywall Types

### Feature Lock Paywall

```
[Lock Icon]
This feature is available on Pro

[Feature preview/screenshot]

[Feature name] helps you [benefit]:
- [Capability]
- [Capability]

[Upgrade to Pro - $X/mo]
[Maybe Later]
```

### Usage Limit Paywall

```
You've reached your free limit

[Progress bar at 100%]

Free: 3 projects | Pro: Unlimited

[Upgrade to Pro]  [Delete a project]
```

### Trial Expiration Paywall

```
Your trial ends in 3 days

What you'll lose:
- [Feature used]
- [Data created]

What you've accomplished:
- Created X projects

[Continue with Pro]
[Remind me later]  [Downgrade]
```

---

## Paywall Timing and Frequency

### When to Show

- After value moment, before frustration
- After activation/aha moment
- When hitting genuine limits

### When NOT to Show

- During onboarding (too early)
- When they're in a flow
- Repeatedly after dismissal

### Frequency Rules

- Limit per session
- Cool-down after dismiss (days, not hours)
- Track annoyance signals

---

## Upgrade Flow Optimization

### From Paywall to Payment

- Minimize steps
- Keep in-context if possible
- Pre-fill known information

### Post-Upgrade

- Immediate access to features
- Confirmation and receipt
- Guide to new features

---

## Anti-Patterns to Avoid

### Dark Patterns

- Hiding the close button
- Confusing plan selection
- Guilt-trip copy

### Conversion Killers

- Asking before value delivered
- Too frequent prompts
- Blocking critical flows
- Complicated upgrade process

---

# Measurement

## Key Metrics

| Element  | Metrics                                                           |
| -------- | ----------------------------------------------------------------- |
| Pages    | Conversion rate, bounce rate, time on page, scroll depth          |
| Popups   | Impression rate, conversion rate, close rate, time to close       |
| Paywalls | Impression rate, click-through, completion rate, revenue per user |

## Benchmarks

- Landing page: 2-5% conversion typical
- Email popup: 2-5% conversion typical
- Exit intent: 3-10% conversion
- Click-triggered: 10%+ (self-selected)

---

# Output Format

## Page/Popup/Paywall Audit

For each issue:

- **Issue**: What's wrong
- **Impact**: Why it matters
- **Fix**: Specific recommendation
- **Priority**: High/Medium/Low

## Recommendations Structure

### Quick Wins (Implement Now)

Easy changes with likely immediate impact.

### High-Impact Changes (Prioritize)

Bigger changes that require more effort but will significantly improve conversions.

### Test Ideas

Hypotheses worth A/B testing rather than assuming.

### Copy Alternatives

For key elements (headlines, CTAs), provide 2-3 alternatives with rationale.

---

# Experiment Ideas

## Page Experiments

**Hero Section**

- Test headline variations (benefit vs. feature vs. social proof)
- Hero image vs. video vs. product screenshot
- CTA button text and color variations
- Single CTA vs. multiple CTAs

**Trust Signals**

- Add/remove/reposition customer logos
- Test testimonial formats (text vs. video)
- Add specific numbers and metrics
- Test security badges placement

**Pricing Presentation**

- Annual vs. monthly default selection
- Show savings percentage for annual
- Number of pricing tiers displayed
- Feature comparison table design

**Navigation and UX**

- Remove navigation on landing pages
- Sticky header with CTA
- Exit-intent elements

---

## Popup Experiments

**Placement & Format**

- Center modal vs. slide-in from corner
- Full-screen overlay vs. smaller modal
- Bottom bar vs. corner popup
- Banner with countdown timer vs. without

**Triggers**

- Exit intent vs. 30-second delay vs. 50% scroll depth
- Test optimal time delay (10s vs. 30s vs. 60s)
- Test scroll depth percentage (25% vs. 50% vs. 75%)
- Page count trigger (show after X pages viewed)

**Messaging**

- Test headline variations
- Urgency-focused copy vs. value-focused copy
- Add countdown timers to create urgency
- Include social proof in popup

**Personalization**

- New vs. returning visitor messaging
- Segment by traffic source
- Tailor content based on pages visited

**Frequency**

- Test frequency capping (once per session vs. once per week)
- Cool-down period after dismissal
- Show escalating offers over multiple visits

---

## Paywall Experiments

**Trigger Testing**

- Test different trigger points (usage %, days, actions)
- Soft paywall (preview) vs. hard paywall (blocked)
- Timing relative to aha moment

**Pricing Display**

- Monthly vs. annual emphasis
- Price anchoring strategies
- Discount presentation

**Value Communication**

- Feature list vs. benefit list
- With/without social proof
- Preview of locked feature

**Design**

- Modal vs. full page
- Size and prominence
- Visual hierarchy

---

# Common Strategies by Business Type

## E-commerce

**Pages**: Hero product, trust badges, urgency
**Popups**:

1. Entry/scroll: First-purchase discount
2. Exit intent: Bigger discount or reminder
3. Cart abandonment: Complete your order

## B2B SaaS

**Pages**: Clear value prop, social proof, demo CTA
**Popups**:

1. Click-triggered: Demo request, lead magnets
2. Scroll: Newsletter/blog subscription
3. Exit intent: Trial reminder or content offer
   **Paywalls**: Feature gates, usage limits, trial expiration

## Content/Media

**Pages**: Content previews, subscription benefits
**Popups**:

1. Scroll-based: Newsletter after engagement
2. Page count: Subscribe after multiple visits
3. Exit intent: Don't miss future content

## Lead Generation

**Pages**: Clear offer, minimal friction
**Popups**:

1. Time-delayed: General list building
2. Click-triggered: Specific lead magnets
3. Exit intent: Final capture attempt

---

# Task-Specific Questions

1. What's your current conversion rate and goal?
2. Where is traffic coming from?
3. What does your signup/purchase flow look like after this element?
4. Do you have user research, heatmaps, or session recordings?
5. What have you already tried?
6. What incentive can you offer? (for popups)
7. What features are behind the paywall? (for paywalls)
8. What's your "aha moment" for users? (for paywalls)
9. Mobile vs. desktop traffic split?
10. Are there compliance requirements (GDPR, etc.)?

---

# Related Skills

- **conversion-flows**: For forms, signup flows, and onboarding
- **copywriting**: For complete copy rewrites
- **email-sequence**: For post-conversion sequences
- **ab-test-setup**: For testing changes
