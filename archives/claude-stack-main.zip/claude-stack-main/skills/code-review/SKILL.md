---
name: code-review
description: Complete guide for bidirectional code review - requesting reviews and receiving feedback with technical rigor
---

# Code Review

Complete guide for the bidirectional code review process.

**Core principles:**

- Review early, review often
- Verify before implementing
- Technical correctness over social comfort

---

## Section 1: Requesting Review

Dispatch superpowers:code-reviewer subagent to catch issues before they cascade.

### When to Request Review

**Mandatory:**

- After each task in subagent-driven development
- After completing major feature
- Before merge to main

**Optional but valuable:**

- When stuck (fresh perspective)
- Before refactoring (baseline check)
- After fixing complex bug

### How to Request

**1. Get git SHAs:**

```bash
BASE_SHA=$(git rev-parse HEAD~1)  # or origin/main
HEAD_SHA=$(git rev-parse HEAD)
```

**2. Dispatch code-reviewer subagent:**

Use Task tool with superpowers:code-reviewer type, fill template at `code-review/code-reviewer.md`

**Placeholders:**

- `{WHAT_WAS_IMPLEMENTED}` - What you just built
- `{PLAN_OR_REQUIREMENTS}` - What it should do
- `{BASE_SHA}` - Starting commit
- `{HEAD_SHA}` - Ending commit
- `{DESCRIPTION}` - Brief summary

**3. Act on feedback:**

- Fix Critical issues immediately
- Fix Important issues before proceeding
- Note Minor issues for later
- Push back if reviewer is wrong (with reasoning)

### Example Request

```
[Just completed Task 2: Add verification function]

You: Let me request code review before proceeding.

BASE_SHA=$(git log --oneline | grep "Task 1" | head -1 | awk '{print $1}')
HEAD_SHA=$(git rev-parse HEAD)

[Dispatch superpowers:code-reviewer subagent]
  WHAT_WAS_IMPLEMENTED: Verification and repair functions for conversation index
  PLAN_OR_REQUIREMENTS: Task 2 from docs/plans/deployment-plan.md
  BASE_SHA: a7981ec
  HEAD_SHA: 3df7661
  DESCRIPTION: Added verifyIndex() and repairIndex() with 4 issue types

[Subagent returns]:
  Strengths: Clean architecture, real tests
  Issues:
    Important: Missing progress indicators
    Minor: Magic number (100) for reporting interval
  Assessment: Ready to proceed

You: [Fix progress indicators]
[Continue to Task 3]
```

### Integration with Workflows

**Subagent-Driven Development:**

- Review after EACH task
- Catch issues before they compound
- Fix before moving to next task

**Executing Plans:**

- Review after each batch (3 tasks)
- Get feedback, apply, continue

**Ad-Hoc Development:**

- Review before merge
- Review when stuck

---

## Section 2: Receiving Review

Code review requires technical evaluation, not emotional performance.

### The Response Pattern

```
WHEN receiving code review feedback:

1. READ: Complete feedback without reacting
2. UNDERSTAND: Restate requirement in own words (or ask)
3. VERIFY: Check against codebase reality
4. EVALUATE: Technically sound for THIS codebase?
5. RESPOND: Technical acknowledgment or reasoned pushback
6. IMPLEMENT: One item at a time, test each
```

### Forbidden Responses

**NEVER:**

- "You're absolutely right!" (performative)
- "Great point!" / "Excellent feedback!" (performative)
- "Let me implement that now" (before verification)
- "Thanks for [anything]" (gratitude expressions)

**INSTEAD:**

- Restate the technical requirement
- Ask clarifying questions
- Push back with technical reasoning if wrong
- Just start working (actions > words)

### Handling Unclear Feedback

```
IF any item is unclear:
  STOP - do not implement anything yet
  ASK for clarification on unclear items

WHY: Items may be related. Partial understanding = wrong implementation.
```

**Example:**

```
Your human partner: "Fix 1-6"
You understand 1,2,3,6. Unclear on 4,5.

WRONG: Implement 1,2,3,6 now, ask about 4,5 later
RIGHT: "I understand items 1,2,3,6. Need clarification on 4 and 5 before proceeding."
```

### Source-Specific Handling

**From your human partner:**

- Trusted - implement after understanding
- Still ask if scope unclear
- No performative agreement
- Skip to action or technical acknowledgment

**From External Reviewers:**

```
BEFORE implementing:
  1. Check: Technically correct for THIS codebase?
  2. Check: Breaks existing functionality?
  3. Check: Reason for current implementation?
  4. Check: Works on all platforms/versions?
  5. Check: Does reviewer understand full context?

IF suggestion seems wrong:
  Push back with technical reasoning

IF can't easily verify:
  Say so: "I can't verify this without [X]. Should I [investigate/ask/proceed]?"

IF conflicts with your human partner's prior decisions:
  Stop and discuss with your human partner first
```

### YAGNI Check for "Professional" Features

```
IF reviewer suggests "implementing properly":
  grep codebase for actual usage

  IF unused: "This endpoint isn't called. Remove it (YAGNI)?"
  IF used: Then implement properly
```

### Implementation Order

```
FOR multi-item feedback:
  1. Clarify anything unclear FIRST
  2. Then implement in this order:
     - Blocking issues (breaks, security)
     - Simple fixes (typos, imports)
     - Complex fixes (refactoring, logic)
  3. Test each fix individually
  4. Verify no regressions
```

### When To Push Back

Push back when:

- Suggestion breaks existing functionality
- Reviewer lacks full context
- Violates YAGNI (unused feature)
- Technically incorrect for this stack
- Legacy/compatibility reasons exist
- Conflicts with your human partner's architectural decisions

**How to push back:**

- Use technical reasoning, not defensiveness
- Ask specific questions
- Reference working tests/code
- Involve your human partner if architectural

### Acknowledging Correct Feedback

When feedback IS correct:

```
"Fixed. [Brief description of what changed]"
"Good catch - [specific issue]. Fixed in [location]."
[Just fix it and show in the code]
```

### Gracefully Correcting Your Pushback

If you pushed back and were wrong:

```
"You were right - I checked [X] and it does [Y]. Implementing now."
"Verified this and you're correct. My initial understanding was wrong because [reason]. Fixing."
```

State the correction factually and move on. No long apologies.

### GitHub Thread Replies

When replying to inline review comments on GitHub, reply in the comment thread (`gh api repos/{owner}/{repo}/pulls/{pr}/comments/{id}/replies`), not as a top-level PR comment.

---

## Section 3: Common Patterns and Anti-Patterns

### Patterns (Do This)

| Pattern                               | Description                                    |
| ------------------------------------- | ---------------------------------------------- |
| Review early, review often            | Catch issues before they cascade               |
| One fix at a time                     | Test each change individually                  |
| Verify before implementing            | Check suggestion against codebase reality      |
| Technical pushback                    | Challenge incorrect suggestions with reasoning |
| Clarify before partial implementation | Ask about ALL unclear items first              |
| YAGNI check                           | Grep codebase before adding "proper" features  |
| Severity-based prioritization         | Critical > Important > Minor                   |

### Anti-Patterns (Never Do This)

| Anti-Pattern                               | Why It's Bad                        |
| ------------------------------------------ | ----------------------------------- |
| Skip review because "it's simple"          | Simple code still has bugs          |
| Performative agreement                     | Wastes time, masks misunderstanding |
| Blind implementation                       | May break existing functionality    |
| Ignore Critical issues                     | Bugs ship to production             |
| Batch without testing                      | Regressions go unnoticed            |
| Avoid pushback for comfort                 | Wrong code gets merged              |
| Partial implementation of unclear feedback | Items may be related                |
| Argue with valid technical feedback        | Wastes time, creates friction       |

### Real Examples

**Performative Agreement (Bad):**

```
Reviewer: "Remove legacy code"
"You're absolutely right! Let me remove that..."
```

**Technical Verification (Good):**

```
Reviewer: "Remove legacy code"
"Checking... build target is 10.15+, this API needs 13+. Need legacy for backward compat. Current impl has wrong bundle ID - fix it or drop pre-13 support?"
```

**YAGNI Application (Good):**

```
Reviewer: "Implement proper metrics tracking with database, date filters, CSV export"
"Grepped codebase - nothing calls this endpoint. Remove it (YAGNI)? Or is there usage I'm missing?"
```

**Unclear Feedback Handling (Good):**

```
Your human partner: "Fix items 1-6"
You understand 1,2,3,6. Unclear on 4,5.
"Understand 1,2,3,6. Need clarification on 4 and 5 before implementing."
```

### Red Flags Checklist

**Never:**

- Skip review because "it's simple"
- Ignore Critical issues
- Proceed with unfixed Important issues
- Argue with valid technical feedback
- Say "Thanks for [anything]"
- Implement before verifying

**If reviewer wrong:**

- Push back with technical reasoning
- Show code/tests that prove it works
- Request clarification

**Signal if uncomfortable pushing back out loud:** "Strange things are afoot at the Circle K"

---

## Quick Reference

### Requesting Review

```bash
BASE_SHA=$(git rev-parse origin/main)
HEAD_SHA=$(git rev-parse HEAD)
# Dispatch superpowers:code-reviewer with template
```

### Receiving Review

```
1. READ complete feedback
2. UNDERSTAND (restate or ask)
3. VERIFY against codebase
4. EVALUATE for THIS codebase
5. RESPOND (technical only)
6. IMPLEMENT (one at a time, test each)
```

### Priority Order

1. Critical - Fix immediately
2. Important - Fix before proceeding
3. Minor - Note for later

---

See template at: code-review/code-reviewer.md
