---
name: market-research
version: 1.0.0
description: "Structured market research and validation for business ideas. Use when the user mentions 'market research,' 'validate idea,' 'market size,' 'TAM SAM SOM,' 'customer research,' 'is this a good idea,' 'market opportunity,' or wants to understand if a business idea is viable before building. Covers problem validation, market sizing, customer discovery, and go/no-go recommendations."
---

# Market Research

You help users validate business ideas and understand market opportunities before investing time and money.

**Announce at start:** "I'm using the market-research skill to validate this opportunity."

---

## Phase 1: Idea Clarification

### Step 1: Capture the Idea

Ask these questions (one at a time):

1. **What's the idea in one sentence?**
2. **Who is this for?** (be specific: role, company size, industry)
3. **What problem does it solve?**
4. **How do they solve it today?** (current alternatives)
5. **Why would they switch to you?**

### Step 2: Clarify Assumptions

List the key assumptions that must be true:

```markdown
## Key Assumptions to Validate

| # | Assumption | Risk if Wrong | How to Test |
|---|------------|---------------|-------------|
| 1 | [Problem exists] | High | Customer interviews |
| 2 | [People will pay] | High | Pricing conversations |
| 3 | [You can reach them] | Medium | Channel testing |
| 4 | [You can build it] | Medium | Technical spike |
```

---

## Phase 2: Problem Validation

### Step 1: Problem Research

Search for evidence the problem exists:

**Sources to check:**
- Reddit, Twitter, forums — Are people complaining?
- G2/Capterra reviews of alternatives — What do they hate?
- Quora, StackOverflow — Are people asking for solutions?
- Google Trends — Is search volume growing?
- Industry reports — Is this a known pain point?

### Step 2: Problem Severity Score

```markdown
## Problem Validation

**Problem statement:** [one sentence]

### Severity Assessment

| Criteria | Score (1-5) | Evidence |
|----------|-------------|----------|
| Frequency (how often) | | |
| Intensity (how painful) | | |
| Willingness to pay | | |
| Current spend on problem | | |
| Urgency to solve | | |
| **Total** | /25 | |

**Interpretation:**
- 20-25: Strong problem, worth pursuing
- 15-19: Moderate problem, needs angle
- 10-14: Weak problem, pivot needed
- <10: No real problem, stop here
```

---

## Phase 3: Market Sizing

### Step 1: TAM SAM SOM

```markdown
## Market Size

### TAM (Total Addressable Market)
Everyone who could theoretically use this.

**Calculation:**
- [X] people/companies in [category]
- Average spend on [problem area]: $[Y]/year
- TAM = X × Y = $[Z]

### SAM (Serviceable Addressable Market)
The segment you can realistically reach.

**Filters applied:**
- Geography: [where you can sell]
- Company size: [your target]
- Tech requirements: [must have X]
- SAM = [subset] × $[spend] = $[Z]

### SOM (Serviceable Obtainable Market)
What you can capture in 1-3 years.

**Realistic capture rate:** [X]% of SAM
- SOM Year 1: $[Z]
- SOM Year 3: $[Z]

### Market Assessment
| Metric | Value | Verdict |
|--------|-------|---------|
| TAM | $ | [Attractive/Niche/Too small] |
| SAM | $ | |
| SOM Y1 | $ | [Viable bootstrapped/Needs funding/Not viable] |
| Growth rate | %/yr | [Growing/Stable/Declining] |
```

### Step 2: Market Dynamics

```markdown
## Market Dynamics

### Growth Drivers
- [What's making this market grow?]

### Headwinds
- [What could slow it down?]

### Timing Assessment
- **Why now?** [What changed that makes this possible/needed?]
- **Why not before?** [What held it back?]
- **Window:** [How long until this opportunity closes?]
```

---

## Phase 4: Competitive Analysis

Reference `competitive-intel` skill for deep analysis. Quick version:

```markdown
## Competitive Landscape (Quick)

### Direct Alternatives
| Solution | Pricing | Weakness | Why you're better |
|----------|---------|----------|-------------------|
| | | | |

### Indirect Alternatives
| Approach | Why used | Limitation |
|----------|----------|------------|
| Do nothing | | |
| Spreadsheets | | |
| Hire someone | | |

### Competitive Advantage
**Your unfair advantage:** [What do you have that's hard to copy?]
- Domain expertise?
- Technical capability?
- Distribution/audience?
- Cost structure?
- Speed?
```

---

## Phase 5: Customer Discovery

### Step 1: Find Target Customers

**Where to find them:**
- LinkedIn (filter by role, company, industry)
- Industry Slack/Discord communities
- Reddit communities
- Twitter lists
- Conference attendee lists
- Your existing network

### Step 2: Interview Script

```markdown
## Customer Interview Guide

**Goal:** Validate problem, not pitch solution.

### Opening (2 min)
"Thanks for chatting. I'm exploring [problem area] and want to understand your experience. No sales pitch — just learning."

### Context (3 min)
- "What's your role?"
- "Walk me through how you handle [problem area] today."

### Problem Deep-Dive (10 min)
- "What's the most frustrating part of [current approach]?"
- "When was the last time this was a problem? What happened?"
- "What did it cost you?" (time, money, stress)
- "Have you tried to solve this? What did you try?"
- "Why didn't that work?"

### Solution Exploration (5 min)
- "If you could wave a magic wand, what would the ideal look like?"
- "What would you pay for that?" (or: "What do you pay now for similar tools?")
- "What would make you switch from your current approach?"

### Closing (2 min)
- "Who else should I talk to?"
- "Can I follow up if I build something?"

### Post-Interview Notes
| Question | Key Quote | Insight |
|----------|-----------|---------|
| | | |
```

### Step 3: Pattern Recognition

After 5-10 interviews:

```markdown
## Interview Synthesis

**Interviews completed:** [N]

### Problem Patterns
| Problem | Frequency | Intensity | Quote |
|---------|-----------|-----------|-------|
| | /10 mentioned | High/Med/Low | "" |

### Current Solutions
| Approach | % Using | Satisfaction |
|----------|---------|--------------|
| | | |

### Willingness to Pay
- Mentioned budget: $[range]
- Current spend on problem: $[X]/month
- Price sensitivity: [High/Medium/Low]

### Key Insights
1.
2.
3.

### Red Flags
-
```

---

## Phase 6: Go/No-Go Recommendation

```markdown
# Market Research Summary: [Idea Name]

*Date: [date]*

## Scorecard

| Criteria | Score (1-5) | Notes |
|----------|-------------|-------|
| Problem severity | | |
| Market size | | |
| Willingness to pay | | |
| Competition manageable | | |
| Timing right | | |
| You can win | | |
| **Total** | /30 | |

## Interpretation
- **25-30:** Strong opportunity — proceed to MVP
- **18-24:** Promising but risky — test further or find angle
- **12-17:** Weak opportunity — pivot or pass
- **<12:** Not viable — stop here

## Recommendation

### Verdict: [GO / CONDITIONAL GO / NO-GO]

### If GO:
- **Next step:** [Build MVP / Run ads test / More interviews]
- **Key risk to monitor:** [Biggest assumption still unvalidated]
- **Success metric:** [What proves you're on track]

### If NO-GO:
- **Why:** [Core issue]
- **Pivot option:** [Alternative angle if any]
- **Learning:** [What to carry forward]
```

---

## Quick Validation (30 min version)

For rapid idea screening:

```markdown
## Quick Validation: [Idea]

### 5 Questions
1. **Can I describe the customer in one sentence?** [Yes/No]
2. **Can I find 10 of them online right now?** [Yes/No]
3. **Are they already paying for something similar?** [Yes/No]
4. **Can I reach them without ads?** [Yes/No]
5. **Can I build a V1 in 2 weeks?** [Yes/No]

**Score:** /5 Yes

- 5/5: Fast-track to MVP
- 3-4: Worth deeper research
- 0-2: Rethink or pass
```

---

## Tips

- **Talk to customers before building** — 10 interviews > 100 hours of coding
- **Look for hair-on-fire problems** — Urgent > important > nice-to-have
- **Beware "I would definitely use that"** — Ask what they DO, not what they WOULD do
- **Small markets can be good** — $10M market you can dominate > $1B market you can't crack
- **Validate willingness to pay early** — Free users ≠ paying customers

---

## Integration

This skill works with:
- `competitive-intel` — Deep competitor analysis
- `brainstorming` — Idea generation and refinement
- `product-marketing-context` — Capture validated insights
- `pricing-strategy` — Set pricing based on research
