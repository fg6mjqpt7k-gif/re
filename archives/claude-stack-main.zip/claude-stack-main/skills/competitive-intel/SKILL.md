---
name: competitive-intel
version: 1.0.0
description: "Automated competitive intelligence and market monitoring. Use when the user mentions 'competitor analysis,' 'competitive landscape,' 'market watch,' 'competitor tracking,' 'what are competitors doing,' 'competitive intel,' or wants to understand how they compare to alternatives. Covers competitor identification, feature comparison, pricing analysis, positioning gaps, and ongoing monitoring."
---

# Competitive Intelligence

You help users gather, analyze, and monitor competitive intelligence to inform business decisions.

**Announce at start:** "I'm using the competitive-intel skill to analyze your competitive landscape."

---

## Phase 1: Scope Definition

### Step 1: Understand the Request

Ask one question at a time:

1. **What's your product/service?** (or reference `product-marketing-context.md` if exists)
2. **What type of analysis do you need?**
   - Quick scan (3-5 competitors, surface level)
   - Deep dive (1-2 competitors, comprehensive)
   - Full landscape (all competitors, categorized)
   - Ongoing monitoring setup

3. **What's the purpose?**
   - Positioning/messaging
   - Pricing decisions
   - Feature roadmap
   - Sales enablement
   - Investor materials

---

## Phase 2: Competitor Identification

### Step 1: Categorize Competitors

```markdown
## Competitive Landscape

### Direct Competitors (same solution, same problem)
| Competitor | One-liner | Target | Est. Size |
|------------|-----------|--------|-----------|
| | | | |

### Secondary Competitors (different solution, same problem)
| Competitor | Approach | Why chosen over you |
|------------|----------|---------------------|
| | | |

### Indirect Competitors (DIY, status quo, adjacent)
| Alternative | Why it persists |
|-------------|-----------------|
| | |
```

### Step 2: Research Sources

Use these sources (in order of reliability):

1. **Their website** - Pricing, features, positioning, customer logos
2. **G2/Capterra reviews** - Real user complaints and praise
3. **LinkedIn** - Company size, hiring patterns, team composition
4. **Crunchbase** - Funding, investors, growth signals
5. **Twitter/X** - Announcements, customer interactions
6. **Job postings** - Tech stack, priorities, expansion plans
7. **Blog/changelog** - Product direction, recent launches

---

## Phase 3: Analysis Frameworks

### Feature Matrix

```markdown
## Feature Comparison

| Feature | You | Comp A | Comp B | Comp C |
|---------|-----|--------|--------|--------|
| Core Feature 1 | :white_check_mark: | :white_check_mark: | :x: | :white_check_mark: |
| Core Feature 2 | :white_check_mark: | :x: | :white_check_mark: | :x: |
| Differentiator | :white_check_mark: | :x: | :x: | :x: |

**Legend:** :white_check_mark: = Yes | :x: = No | ~ = Partial | ? = Unknown
```

### Pricing Analysis

```markdown
## Pricing Comparison

| Competitor | Model | Entry Price | Mid-tier | Enterprise | Value Metric |
|------------|-------|-------------|----------|------------|--------------|
| You | | | | | |
| Comp A | | | | | |
| Comp B | | | | | |

**Observations:**
- Price positioning: [Premium / Mid-market / Budget]
- Common value metric: [seats / usage / flat]
- Your pricing gap: [opportunity or risk]
```

### Positioning Map

```markdown
## Positioning Analysis

### Messaging Comparison
| Competitor | Headline | Primary Claim | Target Audience |
|------------|----------|---------------|-----------------|
| | | | |

### Positioning Map (2x2)
          High Price
              |
    Premium   |   Enterprise
    Boutique  |   Leader
              |
Simple -------+------- Complex
              |
    Budget    |   Feature-rich
    Basic     |   Challenger
              |
          Low Price

**Your position:** [quadrant]
**Gap opportunity:** [underserved quadrant]
```

### SWOT per Competitor

```markdown
## [Competitor Name] SWOT

**Strengths**
-

**Weaknesses**
-

**Opportunities** (for you)
-

**Threats** (to you)
-
```

---

## Phase 4: Deliverables

### Quick Scan Output

```markdown
# Competitive Quick Scan: [Your Product]

*Generated: [date]*

## Top 5 Competitors

### 1. [Name]
- **What they do:**
- **Pricing:**
- **Strength:**
- **Weakness:**
- **Your advantage:**

[Repeat for 2-5]

## Key Takeaways
1.
2.
3.

## Recommended Actions
- [ ]
```

### Deep Dive Output

```markdown
# Competitive Deep Dive: [Competitor Name]

*Generated: [date]*

## Overview
- **Founded:**
- **HQ:**
- **Size:**
- **Funding:**
- **Target:**

## Product Analysis
### Core Features
### Recent Launches (last 6 months)
### Roadmap Signals (from job posts, blogs)

## Go-to-Market
### Positioning
### Pricing
### Channels
### Content Strategy

## Customer Perception
### What users love (from reviews)
### What users hate (from reviews)
### Common complaints

## Competitive Dynamics
### Their strengths vs you
### Their weaknesses vs you
### Where you win deals
### Where you lose deals

## Strategic Recommendations
1.
2.
3.
```

### Full Landscape Output

```markdown
# Competitive Landscape: [Market]

*Generated: [date]*

## Market Overview
- **Market size:**
- **Growth rate:**
- **Key trends:**

## Competitor Map
[Include all frameworks above]

## Battlecards (for sales)

### vs [Competitor A]
**When we win:**
**When we lose:**
**Key talking points:**
-
**Landmines to avoid:**
-
**Knockout question:** "[Question that exposes their weakness]"

## Strategic Summary
### Your defensible advantages
### Vulnerable areas
### Market gaps to exploit
### Threats to monitor
```

---

## Phase 5: Monitoring Setup

### Create Monitoring Checklist

```markdown
# Competitive Monitoring Checklist

## Weekly (15 min)
- [ ] Check competitor Twitter/LinkedIn for announcements
- [ ] Scan ProductHunt for new entrants
- [ ] Review Google Alerts

## Monthly (1 hour)
- [ ] Check competitor pricing pages for changes
- [ ] Read new G2/Capterra reviews
- [ ] Review competitor blog posts
- [ ] Check job postings for signals

## Quarterly (half day)
- [ ] Full feature comparison update
- [ ] Pricing analysis refresh
- [ ] Win/loss analysis with sales
- [ ] Update battlecards

## Tools to Set Up
- [ ] Google Alerts: "[competitor name]", "[product category] launch"
- [ ] Visualping: Monitor pricing pages
- [ ] BuiltWith: Track tech stack changes
- [ ] SimilarWeb: Traffic trends (free tier)
```

---

## Tips

- **Focus on actionable insights** — Don't just list features, explain what it means for the user
- **Capture customer language** — How do reviewers describe competitors? Use their words
- **Look for gaps** — The best opportunities are where no one is serving well
- **Update regularly** — Stale intel is worse than no intel
- **Verify before acting** — Cross-reference multiple sources

---

## Integration

This skill works with:
- `product-marketing-context` — Uses your positioning as baseline
- `copywriting` — Informs differentiation messaging
- `pricing-strategy` — Feeds pricing decisions
- `launch-strategy` — Identifies competitive timing
