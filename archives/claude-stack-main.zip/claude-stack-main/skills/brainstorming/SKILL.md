---
name: brainstorming
description: "You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Covers the complete lifecycle: explore ideas, design, write implementation plans, and execute with review checkpoints."
---

# Brainstorming & Planning

## Overview

Complete lifecycle from idea to implementation: explore intent, design solution, write detailed plans, execute with checkpoints.

**Announce at start:** "I'm using the brainstorming skill to [explore/design/plan/execute]."

---

## Phase 1: Understanding the Idea

- Check current project state (files, docs, recent commits)
- Ask questions **one at a time** to refine the idea
- Prefer multiple choice when possible
- Focus on: purpose, constraints, success criteria

## Phase 2: Exploring Approaches

- Propose 2-3 different approaches with trade-offs
- Lead with your recommendation and explain why
- Present options conversationally

## Phase 3: Presenting the Design

- Present design in sections (200-300 words each)
- Ask after each section if it looks right
- Cover: architecture, components, data flow, error handling, testing
- Be ready to go back and clarify

## Phase 4: Writing the Plan

**Save design to:** `docs/plans/YYYY-MM-DD-<feature-name>.md`

### Plan Document Header

```markdown
# [Feature Name] Implementation Plan

> **For Claude:** Use brainstorming skill (Phase 5) to execute this plan.

**Goal:** [One sentence]
**Architecture:** [2-3 sentences]
**Tech Stack:** [Key technologies]
```

### Task Structure (Bite-Sized: 2-5 min each)

```markdown
### Task N: [Component Name]

**Files:**

- Create: `exact/path/to/file.ts`
- Test: `tests/path/test.ts`

**Step 1: Write failing test**
[Complete test code]

**Step 2: Run test - verify FAIL**
Run: `npm test path/test.ts`

**Step 3: Write minimal implementation**
[Complete implementation code]

**Step 4: Run test - verify PASS**

**Step 5: Commit**
```

**Transition:** "Plan saved. Continue execution now or in parallel session?"

---

## Phase 5: Executing Plans

### Step 1: Load and Review

1. Read plan file critically
2. Raise concerns before starting
3. Create TaskList if no concerns

### Step 2: Execute Batch (3 tasks default)

For each task:

1. Mark as in_progress
2. Follow each step exactly
3. Run verifications
4. Mark as completed

### Step 3: Report and Wait

- Show what was implemented
- Show verification output
- Say: "Ready for feedback."

### Step 4: Continue

- Apply changes if needed
- Execute next batch
- Repeat until complete

### Step 5: Complete

- Use git-workflow skill for merge/PR

**When to STOP:** Blocker, unclear instruction, repeated failures → Ask, don't guess.

---

## Key Principles

- **One question at a time** - Don't overwhelm
- **YAGNI ruthlessly** - Remove unnecessary features
- **Explore alternatives** - 2-3 approaches before settling
- **Bite-sized tasks** - Each step 2-5 minutes
- **DRY, TDD, frequent commits**
- **Never start on main/master** without consent
