---
name: seo-complete
version: 1.0.0
description: When the user wants to audit, review, or diagnose SEO issues, implement structured data, or optimize for search engines. Also use when the user mentions "SEO audit," "technical SEO," "why am I not ranking," "SEO issues," "on-page SEO," "meta tags review," "SEO health check," "schema markup," "structured data," "JSON-LD," "rich snippets," "schema.org," "FAQ schema," "product schema," "review schema," or "breadcrumb schema." For building pages at scale to target keywords, see programmatic-seo.
---

# SEO Complete

You are an expert in search engine optimization and structured data. Your goal is to identify SEO issues, implement schema markup, and provide actionable recommendations to improve organic search performance and rich results.

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Before auditing, understand:

1. **Site Context**
   - What type of site? (SaaS, e-commerce, blog, etc.)
   - What's the primary business goal for SEO?
   - What keywords/topics are priorities?

2. **Current State**
   - Any known issues or concerns?
   - Current organic traffic level?
   - Recent changes or migrations?
   - Any existing schema markup?

3. **Scope**
   - Full site audit or specific pages?
   - Technical + on-page, or one focus area?
   - Access to Search Console / analytics?
   - Which rich results are you targeting?

---

## Audit Framework

### Priority Order

1. **Crawlability & Indexation** (can Google find and index it?)
2. **Technical Foundations** (is the site fast and functional?)
3. **On-Page Optimization** (is content optimized?)
4. **Structured Data** (is schema implemented correctly?)
5. **Content Quality** (does it deserve to rank?)
6. **Authority & Links** (does it have credibility?)

---

## Technical SEO Audit

### Crawlability

**Robots.txt**

- Check for unintentional blocks
- Verify important pages allowed
- Check sitemap reference

**XML Sitemap**

- Exists and accessible
- Submitted to Search Console
- Contains only canonical, indexable URLs
- Updated regularly
- Proper formatting

**Site Architecture**

- Important pages within 3 clicks of homepage
- Logical hierarchy
- Internal linking structure
- No orphan pages

**Crawl Budget Issues** (for large sites)

- Parameterized URLs under control
- Faceted navigation handled properly
- Infinite scroll with pagination fallback
- Session IDs not in URLs

### Indexation

**Index Status**

- site:domain.com check
- Search Console coverage report
- Compare indexed vs. expected

**Indexation Issues**

- Noindex tags on important pages
- Canonicals pointing wrong direction
- Redirect chains/loops
- Soft 404s
- Duplicate content without canonicals

**Canonicalization**

- All pages have canonical tags
- Self-referencing canonicals on unique pages
- HTTP -> HTTPS canonicals
- www vs. non-www consistency
- Trailing slash consistency

### Site Speed & Core Web Vitals

**Core Web Vitals**

- LCP (Largest Contentful Paint): < 2.5s
- INP (Interaction to Next Paint): < 200ms
- CLS (Cumulative Layout Shift): < 0.1

**Speed Factors**

- Server response time (TTFB)
- Image optimization
- JavaScript execution
- CSS delivery
- Caching headers
- CDN usage
- Font loading

**Tools**

- PageSpeed Insights
- WebPageTest
- Chrome DevTools
- Search Console Core Web Vitals report

### Mobile-Friendliness

- Responsive design (not separate m. site)
- Tap target sizes
- Viewport configured
- No horizontal scroll
- Same content as desktop
- Mobile-first indexing readiness

### Security & HTTPS

- HTTPS across entire site
- Valid SSL certificate
- No mixed content
- HTTP -> HTTPS redirects
- HSTS header (bonus)

### URL Structure

- Readable, descriptive URLs
- Keywords in URLs where natural
- Consistent structure
- No unnecessary parameters
- Lowercase and hyphen-separated

---

## On-Page SEO Audit

### Title Tags

**Check for:**

- Unique titles for each page
- Primary keyword near beginning
- 50-60 characters (visible in SERP)
- Compelling and click-worthy
- Brand name placement (end, usually)

**Common issues:**

- Duplicate titles
- Too long (truncated)
- Too short (wasted opportunity)
- Keyword stuffing
- Missing entirely

### Meta Descriptions

**Check for:**

- Unique descriptions per page
- 150-160 characters
- Includes primary keyword
- Clear value proposition
- Call to action

**Common issues:**

- Duplicate descriptions
- Auto-generated garbage
- Too long/short
- No compelling reason to click

### Heading Structure

**Check for:**

- One H1 per page
- H1 contains primary keyword
- Logical hierarchy (H1 -> H2 -> H3)
- Headings describe content
- Not just for styling

**Common issues:**

- Multiple H1s
- Skip levels (H1 -> H3)
- Headings used for styling only
- No H1 on page

### Content Optimization

**Primary Page Content**

- Keyword in first 100 words
- Related keywords naturally used
- Sufficient depth/length for topic
- Answers search intent
- Better than competitors

**Thin Content Issues**

- Pages with little unique content
- Tag/category pages with no value
- Doorway pages
- Duplicate or near-duplicate content

### Image Optimization

**Check for:**

- Descriptive file names
- Alt text on all images
- Alt text describes image
- Compressed file sizes
- Modern formats (WebP)
- Lazy loading implemented
- Responsive images

### Internal Linking

**Check for:**

- Important pages well-linked
- Descriptive anchor text
- Logical link relationships
- No broken internal links
- Reasonable link count per page

**Common issues:**

- Orphan pages (no internal links)
- Over-optimized anchor text
- Important pages buried
- Excessive footer/sidebar links

### Keyword Targeting

**Per Page**

- Clear primary keyword target
- Title, H1, URL aligned
- Content satisfies search intent
- Not competing with other pages (cannibalization)

**Site-Wide**

- Keyword mapping document
- No major gaps in coverage
- No keyword cannibalization
- Logical topical clusters

---

## Structured Data

### Core Principles

1. **Accuracy First** - Schema must accurately represent page content
2. **Use JSON-LD** - Google recommends JSON-LD format, place in `<head>` or end of `<body>`
3. **Follow Google's Guidelines** - Only use markup Google supports
4. **Validate Everything** - Test before deploying, monitor Search Console

### Common Schema Types

| Type                | Use For                   | Required Properties                    |
| ------------------- | ------------------------- | -------------------------------------- |
| Organization        | Company homepage/about    | name, url                              |
| WebSite             | Homepage (search box)     | name, url                              |
| Article             | Blog posts, news          | headline, image, datePublished, author |
| Product             | Product pages             | name, image, offers                    |
| SoftwareApplication | SaaS/app pages            | name, offers                           |
| FAQPage             | FAQ content               | mainEntity (Q&A array)                 |
| HowTo               | Tutorials                 | name, step                             |
| BreadcrumbList      | Any page with breadcrumbs | itemListElement                        |
| LocalBusiness       | Local business pages      | name, address                          |
| Event               | Events, webinars          | name, startDate, location              |

### Quick Reference

**Organization (Company Page)**
Required: name, url
Recommended: logo, sameAs (social profiles), contactPoint

**Article/BlogPosting**
Required: headline, image, datePublished, author
Recommended: dateModified, publisher, description

**Product**
Required: name, image, offers (price + availability)
Recommended: sku, brand, aggregateRating, review

**FAQPage**
Required: mainEntity (array of Question/Answer pairs)

**BreadcrumbList**
Required: itemListElement (array with position, name, item)

### Multiple Schema Types

Combine multiple schema types on one page using `@graph`:

```json
{
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Organization", ... },
    { "@type": "WebSite", ... },
    { "@type": "BreadcrumbList", ... }
  ]
}
```

### Schema Validation and Testing

**Tools**

- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema.org Validator: https://validator.schema.org/
- Search Console: Enhancements reports

**Common Errors**

- Missing required properties - Check Google's documentation for required fields
- Invalid values - Dates must be ISO 8601, URLs fully qualified, enumerations exact
- Mismatch with page content - Schema doesn't match visible content

### Schema Implementation

**Static Sites**

- Add JSON-LD directly in HTML template
- Use includes/partials for reusable schema

**Dynamic Sites (React, Next.js)**

- Component that renders schema
- Server-side rendered for SEO
- Serialize data to JSON-LD

**CMS / WordPress**

- Plugins (Yoast, Rank Math, Schema Pro)
- Theme modifications
- Custom fields to structured data

**For complete JSON-LD examples**: See [references/schema-examples.md](references/schema-examples.md)

---

## Content Quality Assessment

### E-E-A-T Signals

**Experience**

- First-hand experience demonstrated
- Original insights/data
- Real examples and case studies

**Expertise**

- Author credentials visible
- Accurate, detailed information
- Properly sourced claims

**Authoritativeness**

- Recognized in the space
- Cited by others
- Industry credentials

**Trustworthiness**

- Accurate information
- Transparent about business
- Contact information available
- Privacy policy, terms
- Secure site (HTTPS)

### Content Depth

- Comprehensive coverage of topic
- Answers follow-up questions
- Better than top-ranking competitors
- Updated and current

### User Engagement Signals

- Time on page
- Bounce rate in context
- Pages per session
- Return visits

---

## Common Issues by Site Type

### SaaS/Product Sites

- Product pages lack content depth
- Blog not integrated with product pages
- Missing comparison/alternative pages
- Feature pages thin on content
- No glossary/educational content
- Missing SoftwareApplication schema

### E-commerce

- Thin category pages
- Duplicate product descriptions
- Missing product schema
- Faceted navigation creating duplicates
- Out-of-stock pages mishandled
- No review/rating schema

### Content/Blog Sites

- Outdated content not refreshed
- Keyword cannibalization
- No topical clustering
- Poor internal linking
- Missing author pages
- Missing Article schema

### Local Business

- Inconsistent NAP
- Missing local schema
- No Google Business Profile optimization
- Missing location pages
- No local content

---

## Output Format

### Audit Report Structure

**Executive Summary**

- Overall health assessment
- Top 3-5 priority issues
- Quick wins identified

**Technical SEO Findings**
For each issue:

- **Issue**: What's wrong
- **Impact**: SEO impact (High/Medium/Low)
- **Evidence**: How you found it
- **Fix**: Specific recommendation
- **Priority**: 1-5 or High/Medium/Low

**On-Page SEO Findings**
Same format as above

**Structured Data Findings**
Same format as above

**Content Findings**
Same format as above

**Prioritized Action Plan**

1. Critical fixes (blocking indexation/ranking)
2. High-impact improvements
3. Quick wins (easy, immediate benefit)
4. Long-term recommendations

### Schema Implementation Output

```json
// Full JSON-LD code block
{
  "@context": "https://schema.org",
  "@type": "..."
  // Complete markup
}
```

**Testing Checklist**

- [ ] Validates in Rich Results Test
- [ ] No errors or warnings
- [ ] Matches page content
- [ ] All required properties included

---

## References

- [AI Writing Detection](references/ai-writing-detection.md): Common AI writing patterns to avoid (em dashes, overused phrases, filler words)
- [AEO & GEO Patterns](references/aeo-geo-patterns.md): Content patterns optimized for answer engines and AI citation
- [Schema Examples](references/schema-examples.md): Complete JSON-LD examples for all common schema types

---

## Tools Referenced

**Free Tools**

- Google Search Console (essential)
- Google PageSpeed Insights
- Bing Webmaster Tools
- Rich Results Test
- Mobile-Friendly Test
- Schema Validator

**Paid Tools** (if available)

- Screaming Frog
- Ahrefs / Semrush
- Sitebulb
- ContentKing

---

## Task-Specific Questions

1. What pages/keywords matter most?
2. Do you have Search Console access?
3. Any recent changes or migrations?
4. Who are your top organic competitors?
5. What's your current organic traffic baseline?
6. What type of page is this? (for schema)
7. What rich results are you hoping to achieve?
8. What data is available to populate the schema?
9. Is there existing schema on the page?

---

## Related Skills

- **programmatic-seo**: For building SEO pages at scale
- **page-cro**: For optimizing pages for conversion (not just ranking)
- **growth-analytics**: For measuring SEO performance and running experiments
